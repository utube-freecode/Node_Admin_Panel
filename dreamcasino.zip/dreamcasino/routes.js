'use strict';

let authRoutes = require('./app/routes/auth.routes');
let walletRoute = require('./app/routes/wallet.routes');
let panelRoute = require('./app/routes/panel.routes');

module.exports = (app) => {
    app.use('/auth', authRoutes);
    app.use('/wallet',walletRoute)
    app.use('/panel',panelRoute)
};