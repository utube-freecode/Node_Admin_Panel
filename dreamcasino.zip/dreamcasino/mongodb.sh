#!/bin/bash 

sudo sync; echo 1 > /proc/sys/vm/drop_caches
sudo sync; echo 2 > /proc/sys/vm/drop_caches
sudo sync; echo 3 > /proc/sys/vm/drop_caches

kill -9 $(lsof -t -i:5555)
kill -9 $(lsof -t -i:5050)
kill -9 $(lsof -t -i:4848)
clear
sudo systemctl start mongod
