module.exports = {
    apps: [{
        name: "matchApi",
        script: "./app.js",
        instances: 4,
        exec_mode: "cluster",
        error_file: './log/matchApi-error.log',
        out_file: './log/matchApi-out.log',
        log_file: './log/matchApi-combined.log',
        watch: false,
        env: {
            "NODE_ENV": "production",
        },
    }]
}

//pm2 set pm2-logrotate:rotateInterval '0 0 */2 * *'
// ecosystem.config.js