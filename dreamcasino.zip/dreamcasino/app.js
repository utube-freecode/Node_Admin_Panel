'use strict';

process.env.NODE_ENV = process.env.NODE_ENV || 'development';
process.env.CONST_FILE = process.env.CONST_FILE || 'constants';
let express = require('express');
let app = express();
let bodyParser = require('body-parser');
let mongoose = require('mongoose');
let Promise = require('bluebird');
let port = process.env.PORT || 4545;
var server = app.listen(port);

let Sentry = require("@sentry/node");
let Tracing = require("@sentry/tracing");

let config = require(`./config/${process.env.NODE_ENV}.js`);
let compression = require('compression');
const error = require('./app/helpers/error');
var Helpers = require('./app/helpers/common.helper');
var schedule = require('node-schedule');
let validator = require('express-validator');
let requestify = require('requestify');
let _ = require('underscore');
let shell = require('shelljs');
var cors = require('cors');
var redisc = require('redis');
let constants = require(`./config/constants.js`);

require('./app/helpers/logging')();
require('./app/helpers/validation')();
mongoose.Promise = Promise;
let mongoOptions = { poolSize: 100 };
console.log('Mongo Options: ', mongoOptions);
console.log('config.database.URI,', config.database.URI);
console.log('config.mongoOptions.URI,', mongoOptions);
mongoose.connect(
    config.database.URI, { useNewUrlParser: true }
);
let socketIO = require('socket.io');
var redis = require('socket.io-redis');

var allowedOrigins = '*:*';
let io = socketIO(server, {
    origins: allowedOrigins
});

app.set('socketio', io);
io.set('transports', ['websocket',
    'flashsocket',
    'htmlfile',
    'xhr-polling',
    'jsonp-polling',
    'polling'
]);

Sentry.init({
    dsn:constants.sentryUrl,
    integrations: [
      new Sentry.Integrations.Http({ tracing: true }),
      new Tracing.Integrations.Express({ app }),
    ],
    tracesSampleRate: 1.0,
});
app.use(Sentry.Handlers.requestHandler());
app.use(Sentry.Handlers.tracingHandler());
app.use(Sentry.Handlers.errorHandler());
  
app.use(function onError(err, req, res, next) {
    console.log("err++++++++++++++++",err);
    res.statusCode = 500;
    // res.end(res.sentry + "\n");
});

var allowcatedIP = [
    '122.170.70.58', // local
    '173.212.238.127', // pam11
    '62.171.172.154', // redis 
    '95.111.229.236' // samudra new
];
redis({ host: constants.redisServer.dbHost, port: 27019, auth_pass: constants.redisServer.dbOptions.auth_pass });


io.on('connection', (socket) => {
    socket.on('join-room', (roomId) => {
        socket.join(roomId);
    });

    socket.on('leave-room', (roomId) => {
        socket.leave(roomId);
    });
    socket.on('disconnect', (reason) => {
        console.log("reason> ", reason);
        console.log(`Disconnected: ${error || reason}`);
    });
});


app.use(cors({ credentials: true, origin: '*' }));
app.use(cors());
app.use(bodyParser.urlencoded(config.bodyParser.urlencoded));
//app.use(bodyParser.json(config.bodyParser.json));
// app.use(bodyParser.json(config.bodyParser.json));
app.use(bodyParser.text({
    type: 'application/json'
  }));

app.use(compression());
app.use(validator());

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/index.html')
});

app.use(express.static(__dirname + '/index.html'));

require('./routes.js')(app);
app.use(error);

console.log('Match API running now. ' + port);