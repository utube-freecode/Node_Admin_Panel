'use strict';

module.exports = {

    database: {
        //URI: 'mongodb://localhost:27017/smdc'
        URI: 'mongodb://cyberpunkstart:DarkAlliance#REdis98vk@51.159.22.148:55545/smdc-new?authSource=admin' 
    },
    bodyParser: {
        urlencoded: {
            limit: '50mb',
            extended: true,
            parameterLimit: 50000
        },
        json: {
            limit: '50mb'
        }
    },
    scheduler: {
        enable: false,
        period: 1 //In Seconds
    },

    threshold: {
        docsLimit: 500000
    },
    // redis: {
    //     port: 6379,
    //     debug: false,
    //     dbHost: '127.0.0.1',
    //     dbOptions: {
    //         auth_pass: '',
    //         no_ready_check: true,
    //     }
    // },
    

};