'use strict';

module.exports = {

    adminhash: '%U9P7@UqkyMCUJna^CGB7eF=k5vp',
    adminsecret: 'm@NUa9yEJT-$$z%Dcu$jZQsyx3jxM?cy',
    admintempkey: '-$$7@m@NUa9y$jZQkGnwjxM%Dcu?cy$$',
    aessecret: 'Ww?bc=m5$xHuI{s{"bnv',
    secret: 'bqwOlSSbg9VLtQuMp3mB7OAWQQwrvj6V',
    saltRounds: '10',
    JWTsecret: '2Sq2xLxgzpqRoDc4RzLb1arujvDer2Uf',
    kiteGenerateToken: 'session/token',
    kite: {
        api_key: "irfh5xmaiokuz1h8",
        secret: "htnrbuek4drj30dpjfo9yc1uz2n8tlbc",
        request_token: "",
        access_token: "",
    },
    redisServer: {
        dbPort: 27019,
        debug: false,
        // dbHost: 'sportredis.gamefeeds.ml',
        dbHost: 'redis.getlivefeed.xyz',
        dbOptions: {
            auth_pass: 'codebrik#321',
            no_ready_check: true,
        }
    },
    kiteOption: {
        "api_key": "irfh5xmaiokuz1h8",
        "debug": false
    },
    dateFormat: 'dd-mm-yyyy',
    dateTimeFormat: 'dd-mm-yyyy HH:MM:ss',
    partnerId : 'samudra',
    sentryUrl : 'http://498cfc351f064268a8f3034a35073994@sentry.acubeinfosystem.com:9000/13' //live 
};