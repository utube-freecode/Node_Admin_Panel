'use strict';

process.env.NODE_ENV = process.env.NODE_ENV || 'development';
process.env.CONST_FILE = process.env.CONST_FILE || 'constants';
let express = require('express');
let app = express();
let bodyParser = require('body-parser');
let mongoose = require('mongoose');
let Promise = require('bluebird');
let port = process.env.PORT || 3232;
// let http = require('http');
// let server = http.Server(app);
var server = app.listen(port);

// let config = require(`./config/production.js`);
let config = require(`./config/${process.env.NODE_ENV}.js`);
let compression = require('compression');
const error = require('./app/helpers/error');
var schedule = require('node-schedule');
let validator = require('express-validator');
let requestify = require('requestify');
let _ = require('underscore');
let shell = require('shelljs');

var cors = require('cors');

// var Redisclient = redis.createClient(); //creates a new client


var redisc = require('redis');
var Redisclient = redisc.createClient(
    config.redis.port,
    config.redis.dbHost,
    config.redis.dbOptions
);

require('./app/helpers/logging')();
require('./app/helpers/validation')();
mongoose.Promise = Promise;
let mongoOptions = { poolSize: 100 };
console.log('Mongo Options: ', mongoOptions);
console.log('config.database.URI,', config.database.URI);
console.log('config.mongoOptions.URI,', mongoOptions);
mongoose.connect(
    config.database.URI, { useNewUrlParser: true }
);
let socketIO = require('socket.io');
var redis = require('socket.io-redis');

let roomAry = [];
// // var allowedOrigins = "http://173.212.238.127:*, http: //socket.myfancy.xyz:*, http: //office.myfancy.xyz:*,    http: //admin.myfancy.xyz:*,    http: //server.myfancy.xyz:*,    http: //myfancy.xyz:*,http: //www.myfancy.xyz:*,    http: //socket.pam11.com:*,     http: //office.pam11.com:*,    http: //admin.pam11.com:*,    http: //server.pam11.com:*,    http: //pam11.com:*,http: //www.pam11.com:*,    http: //socket.samudra9exch.com:*,    http: //office.samudra9exch.com:*,   http: //admin.samudra9exch.com:*,    http: //server.samudra9exch.com:*,    http: //samudra9exch.com:*,http: //www.samudra9exch.com:*,    http: //socket.pam555.xyz:*,    http: //office.pam555.xyz:*,    http: //admin.pam555.xyz:*,    http: //server.pam555.xyz:*,    http: //pam555.xyz:*,http: //www.pam555.xyz:*,    http: //socket.a1live.xyz:*,    http: //office.a1live.xyz:*,    http: //admin.a1live.xyz:*,    http: //server.a1live.xyz:*,    http: //a1live.xyz:*,http: //www.a1live.xyz:*";
var allowedOrigins = '*:*';
let io = socketIO(server, {
    origins: allowedOrigins
});
// let io = ();
app.set('socketio', io);
io.set('transports', ['websocket',
    'flashsocket',
    'htmlfile',
    'xhr-polling',
    'jsonp-polling',
    'polling'
]);


//io.adapter(redis({ host: 'localhost', port: 6379 }));
io.adapter(redis({
    host: config.redis.dbHost,
    port: config.redis.port,
    auth_pass: config.redis.dbOptions.auth_pass
}));
var allowcatedIP = [
    '122.170.70.58', // local
    '173.212.238.127', // pam11
    '62.171.172.154', // redis 
    '95.111.229.236' // samudra new
];

// io.use((socket, next) => {
//     // console.log(req.header('x-real-ip'));    
//     var ip = socket.request.connection.remoteAddress;
//     if (ip.substr(0, 7) == "::ffff:") { ip = ip.substr(7); }
//     console.log("ip> ", ip);
//     if (_.indexOf(allowcatedIP, ip) > -1) {
//         next();
//     } else {
//         console.log('Unauthorized:');
//         error = reason.message;
//         socket.disconnect();
//     }
// });


io.on('connection', (socket) => {
    console.log('user connected');


    socket.on('join-room', (roomId) => {
        console.log(">join-room > ", roomId);
        socket.join(roomId);
    });

    socket.on('leave-room', (roomId) => {
        console.log(">leave-room > ", roomId);
        socket.leave(roomId);
    });


    // socket.on('api-obj', (message) => {
    //     console.log(message);
    //     //io.emit('api-obj', message);
    //     io.sockets.emit('api-obj', message);
    // });

    // socket.on('change-status', (status) => {
    //     io.emit('change-status', status);
    // });

    // socket.on('cancelMarket', (status) => {
    //     io.emit('cancelMarket', status);
    // });

    // socket.on('logoutByAdmin', (status) => {
    //     io.emit('logoutByAdmin', status);
    // });

    // socket.on('updateBalancebyAdmin', (status) => {
    //     io.emit('updateBalancebyAdmin', status);
    // });


    socket.on('disconnect', (reason) => {
        console.log("reason> ", reason);
        console.log(`Disconnected: ${error || reason}`);
    });

});


app.use(cors({ credentials: true, origin: '*' }));

app.use(cors());
app.use(bodyParser.urlencoded(config.bodyParser.urlencoded));
app.use(bodyParser.json(config.bodyParser.json));
app.use(compression());
app.use(validator());


app.get('/', function(req, res) {
    res.send('')
});
app.use(express.static(__dirname + '/public'));

require('./routes.js')(app);
app.use(error);

let oddsApi = require('./app/models/oddsApi.model');

var requestArray = {
    method: 'GET',
    // body: bodyData,
    headers: {
        'Content-Type': 'application/json',
    },
    dataType: 'json'
};
let url = "http://rate.999exch.com/api/fancyrate/22966";
requestify.get(url).then(function(response) {
    // console.log(response);
    console.log(response);
}).catch(err => {
    console.log(err);
})

return false;

const promise1 = new Promise(function(resolve, reject) {
    resolve(oddsApi.findOne({ isActive: true, type: "market" }).exec());
});

promise1.then(function(value) {

    if (!_.isNull(value)) {
        var apiActiveURL = value.apiUrl;
        var apiName = value.apiName;
        console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>");
        console.log('API_NAME : ', value.apiName);
        console.log("API_URL", apiActiveURL);
        console.log(">>>>>>>>>>>>>>>>>>>>>>>>>>>");

        // *    *    *    *    *    *
        // ┬    ┬    ┬    ┬    ┬    ┬
        // │    │    │    │    │    │
        // │    │    │    │    │    └ day of week (0 - 7) (0 or 7 is Sun)
        // │    │    │    │    └───── month (1 - 12)
        // │    │    │    └────────── day of month (1 - 31)
        // │    │    └─────────────── hour (0 - 23)
        // │    └──────────────────── minute (0 - 59)
        // └───────────────────────── second (0 - 59, OPTIONAL)

        var j = schedule.scheduleJob('*/1 * * * * *', function(fireDate) {

            Redisclient.get("matchAllList", function(err, response) {
                if (err) throw err;
                startInervalofMatch((JSON.parse(response)).join());
            });
            // console.log('This job was supposed to run at ' + new Date);

        });


        // io.origins((origin, callback) => {
        //     console.log("origin> ", origin);
        //     // if (origin !== 'https://foo.example.com') {
        //     //   return callback('origin not allowed', false);
        //     // }
        //     // callback(null, true);
        // });

        function startInervalofMatch(matchIds) {

            var i = 0;
            var timeer = setInterval(function() {
                //live match bhav api
                //var url = 'http://34.251.241.195:8001/api/betfair/' + matchIds;

                //Delay bhav api.
                // var url = 'http://game555.ml?market_id=' + matchIds + '&method=get_bhav&ip=development';
                // var url = apiActiveURL + matchIds;
                // var url = 'http://game555.ml?market_id=1.174162342,1.174202586,1.174346143,1.174171382,1.174171034,1.174202753,1.174202754,1.174170867,1.174171035,1.174171036,1.174171033,1.174171383&method=get_bhav&ip=development';
                if (apiName != 'S_PAY') {
                    var chunckArray = _.chunk(matchIds.split(','), 12);
                    var k = 0;
                    chunckArray.forEach(element => {
                        var url = apiActiveURL + (element.join());
                        requestify.get(url).then(function(response) {
                            // Get the response body
                            // console.log(response.getCode());
                            if (response.getCode() == 200) {
                                var bodyData = response.getBody();
                                if (apiName == 'S_PAY') {
                                    bodyData = bodyData.result;
                                }
                                bodyData = (typeof bodyData == "string") ? (JSON.parse(bodyData)) : bodyData;
                                // console.log(bodyData);
                                bodyData.forEach(element => {
                                    if (!_.isNull(element)) {
                                        prepareTooltoSend(io, element)
                                        Redisclient.set(element.marketId, JSON.stringify(element));
                                    }
                                });
                            }
                        }).catch(error => {
                            console.log("ERROR", error);
                        });
                        if (i == 1) { clearInterval(timeer); }
                    });
                    i = i + 1;
                } else {
                    var chunckArray = matchIds;
                    var k = 0;
                    var url = apiActiveURL + matchIds;
                    requestify.get(url).then(function(response) {
                        if (response.getCode() == 200) {
                            var bodyData = response.getBody();
                            if (apiName == 'S_PAY') {
                                bodyData = bodyData.result;
                            }
                            bodyData = (typeof bodyData == "string") ? (JSON.parse(bodyData)) : bodyData;
                            bodyData.forEach(element => {
                                if (!_.isNull(element)) {
                                    prepareTooltoSend(io, element)
                                    Redisclient.set(element.marketId, JSON.stringify(element));
                                }
                            });
                        }
                    }).catch(error => {
                        console.log("ERROR", error);
                    });
                    if (i == 1) { clearInterval(timeer); }
                    i = i + 1;
                }

            }, 450);

            console.log();

        }

        function prepareTooltoSend(io, matchOdd) {
            var runnersArray = [];
            var Justforthis = {};
            var now = new Date();
            var matchOddrunners = matchOdd.runners;
            runnersArray = matchOddrunners;
            matchOdd.lastMatchTime = (_.isUndefined(matchOdd.lastMatchTime) === false) ? matchOdd.lastMatchTime : '';
            // now prepare insert array 
            var insertData = {
                marketId: matchOdd.marketId,
                isMarketDataDelayed: matchOdd.isMarketDataDelayed,
                status: matchOdd.status,
                betDelay: matchOdd.betDelay,
                bspReconciled: matchOdd.bspReconciled,
                complete: matchOdd.complete,
                inplay: matchOdd.inplay,
                numberOfWinners: matchOdd.numberOfWinners,
                numberOfRunners: matchOdd.numberOfRunners,
                numberOfActiveRunners: matchOdd.numberOfActiveRunners,
                lastMatchTime: matchOdd.lastMatchTime,
                totalMatched: matchOdd.totalMatched,
                crossMatching: matchOdd.crossMatching,
                totalAvailable: matchOdd.totalAvailable,
                runnersVoidable: matchOdd.runnersVoidable,
                version: matchOdd.version,
                runners: runnersArray
            };

            io.sockets.to(matchOdd.marketId).emit('odds-rate', insertData);

        }
    }

});









console.log('Match API running now. ' + port);