#!/bin/bash 
kill -9 $(lsof -t -i:4848)

#NODE_ENV=development TZ="Asia/Calcutta" nodemon app.js

pm2 delete redismatchportal
NODE_ENV=development TZ="Asia/Calcutta" pm2 start app.js --name redismatchportal --watch && pm2 logs redismatchportal


#NODE_ENV=development TZ="Asia/Calcutta" nodemon app.js
# nodemon app.js NODE_ENV=development TZ="Asia/Calcutta" 

# NODE_ENV=production nodemon app.js
# NODE_ENV=production TZ="Asia/Calcutta" pm2 start app.js --name BBMarket_main
# BBMarket_main


#NODE_ENV=production nodemon server2.js

# NODE_ENV=production nodejs app.js
