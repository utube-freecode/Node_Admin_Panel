let express = require('express');
let router = express.Router();
let authController = require('../controllers/auth.controller');
let Authentication = require('../helpers/auth.helper');
router.post('/balance', /*Authentication.ensure,*/ authController.getBalance);
// router.post('/win', /*Authentication.ensure,*/ authController.credit);
router.post('/resultrequest', /*Authentication.ensure,*/ authController.credit); 
// router.post('/bet', /*Authentication.ensure,*/ authController.debit);
router.post('/betrequest', /*Authentication.ensure,*/ authController.debit);
// router.post('/rollback', /*Authentication.ensure,*/ authController.rollback);
router.post('/rollbackrequest', /*Authentication.ensure,*/ authController.rollback);
router.post('/rollback-unchecked', /*Authentication.ensure,*/ authController.rollbackUnchecked);
router.post("/game-list",authController.gameList);
router.post("/game-redis",authController.gameListRedis);
router.post("/game-redis-stag",authController.gameListRedis);

router.post("/save-gameList",authController.saveGameList);

router.post("/game-url", authController.gameUrl);
router.post("/login", authController.login); 

router.post("/get-record", authController.getRecord);
router.post("/re-settle", authController.reSettle);
router.post("/get-unsettled-bet", authController.getUnsettledBet);



module.exports = router;