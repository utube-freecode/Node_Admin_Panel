let express = require('express');
let router = express.Router();
let authController = require('../controllers/auth.controller');
let Authentication = require('../helpers/auth.helper');
router.get('/get-token', /*Authentication.ensure,*/ authController.createToken);
router.post('/authentication', /*Authentication.ensure,*/ authController.authentication);
router.post('/get-new-token', /*Authentication.ensure,*/ authController.getNewToken);
router.post('/store-user-data', /*Authentication.ensure,*/ authController.storeUserData);
router.post('/get-balance', /*Authentication.ensure,*/ authController.getBalance);
router.post('/credit', /*Authentication.ensure,*/ authController.credit);
router.post('/debit', /*Authentication.ensure,*/ authController.debit);
router.post('/rollback', /*Authentication.ensure,*/ authController.rollback);
router.post("/rollback-unchecked", /*Authentication.ensure,*/ authController.rollbackUnchecked);
router.post("/game-list",authController.gameList);
router.post("/game-url", authController.gameUrl);


module.exports = router;