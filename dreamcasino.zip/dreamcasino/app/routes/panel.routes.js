let express = require('express');
let router = express.Router();
let panelController = require('../controllers/panel.controller');
let Authentication = require('../helpers/auth.helper');


router.get('/welcome', /*Authentication.ensure,*/ panelController.welcome);

router.post('/getuserrequests', panelController.getUserRequestList);

router.post('/getgenerallogs', panelController.getGeneralLogs);

router.post('/getgenerallogbyid', panelController.getGeneralLogById);

router.post('/getgeneralloganalysis', panelController.getGeneralLogAnalysis);

router.post('/getgenerallogvisualanalysis', panelController.getGeneralLogVisualAnalysis);

router.post('/getgenerallogvisualanalysisamount', panelController.getGeneralLogVisualAnalysisAmount);

router.post('/getanalysisbygames', panelController.getAnalysisByGames);

router.post('/getanalysisbyproviders', panelController.getAnalysisByProviders);

router.post('/getanalysistotal', panelController.getAnalysisTotal);

router.post('/getwinanalysisbygames', panelController.getWinAnalysisByGames);

router.post('/getwinanalysisbyproviders', panelController.getWinAnalysisByProviders);

router.post('/getwinanalysisbygamesuser', panelController.getWinAnalysisByGamesUser);

router.post('/getwinanalysisbyprovidersuser', panelController.getWinAnalysisByProvidersUser);

router.post('/getwinanalysisbygamesuserinfo', panelController.getWinAnalysisByGamesUserArray);

router.post('/getanalysiscount', panelController.getAnalysisCount);

router.post('/insertgames', panelController.insertGames);

router.post('/getactivegames', panelController.getActiveGames);

router.patch('/modifygamestatusbyid', panelController.modifyGameStatusById);

module.exports = router;