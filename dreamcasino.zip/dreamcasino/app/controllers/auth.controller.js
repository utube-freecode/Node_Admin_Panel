let User = require('../models/user.model');
let Helper = require('../helpers/common.helper');
let userRequest = require('../models/userRequest.model');
let GeneralReqResData = require('../models/generalReqResLogs.model');
let Settled = require('../models/settled.model');
let Settledevent = require('../models/settledevent.model');
let whitelabel = require('../models/whitelabel.model');
let Reaction = require('../models/reaction.model');
var requestify = require('requestify');
const fs = require("fs");
const path = require("path");
let async = require('async');
var crypto = require('crypto');
let constants = require(`../../config/constants`);
let gameList = require(`../../config/gameListLive.json`);
const { networkInterfaces } = require('os');
const axios = require('axios');
var redis = require('redis');
let Constants = require(`../../config/constants`);
let gameListJson = require(`../../app/services/gameListLive.json`);
let partnerId = constants.partnerId;
 let private_keyPath = path.resolve("/home/smdcnew/dreamcasino/app/services/PrivateKeyLive.txt");
 let public_keyPath =  path.resolve("/home/smdcnew/dreamcasino/app/services/PublicKeyLive.txt");
//   let private_keyPath = path.resolve("/media/roy/6e4fd71d-0ad4-4641-b2f8-2f3644c64595/var/www/html/projects/dreamcasino/app/services/PrivateKeyLive.txt");
//   let public_keyPath =  path.resolve("/media/roy/6e4fd71d-0ad4-4641-b2f8-2f3644c64595/var/www/html/projects/dreamcasino/app/services/PublicKeyLive.txt");

var Redisclient = redis.createClient(
    Constants.redisServer.dbPort,
    Constants.redisServer.dbHost,
    Constants.redisServer.dbOptions
);
const jwt = require("jsonwebtoken");
let secretKey = process.env.JWT_SECRET;
let _ = require('lodash');
let ProviderRequest = require('../models/providerRequest.model');
let ErrorLog = require('../models/errorlog.model');
const json2xls = require('json2xls');

module.exports = {

    createToken: (req, res, next) => {
        let strBody = req.body;
        req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;

        let authToken = Helper.getRandomString(20);
        res.status(200).send({
            "status": true,
            "message": "successfully created",
            "token": authToken
        })
    },
    authentication :  (req, res, next) => {
        let strBody = req.body;
        req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        req.checkBody("operatorId", "operatorId is a mandatory.").notEmpty();
        req.checkBody("token", "token mandatory filed.").notEmpty();
        var errors = req.validationErrors();
        if (errors) {
            res.status(200).send({"status":false, "message": errors[0].msg });
        } else {
            let hash = req.get('hash');
            let playersTokenAtLaunch = req.body.token;
            userRequest.findOne({
                playersTokenAtLaunch: playersTokenAtLaunch
            }, function(err, result) {
                if(result){
                    checkHash(strBody,hash).then(checkHash =>  {
                        if(checkHash == false){
                            getLatetsBalance(result).then(balance =>  {
                                balance.errorCode = 1;
                                balance.errorDescription = "Invalid hash.";
                                balance.operatorId = req.body.operatorId;
                                balance.transactionId = req.body.transactionId;
                                balance.roundId = req.body.roundId;
                                res.status(200).send(balance);      
                            });
                        }else{
                            let token = Helper.getRandomString(20);
                            getLatetsBalance(result).then(balance =>  {
                                let resObj = {   
                                    operatorId:req.body.operatorId,
                                    uid:result.userId,
                                    nickName:result.userName,
                                    token :token,
                                    currency :result.currency,
                                    balance:balance.balance,
                                    timestamp : Math.floor(new Date().valueOf()),
                                    errorCode:0,
                                    errorDescription:"ok"
                                }
                                result.token = token;
                                result.playersTokenAtLaunch = Helper.getRandomString(20);                             
                                result.save();
                                res.status(200).send(resObj);    
                            });
                        }
                    });
                }else{
                    let resObj = {   
                        errorCode:6,
                        errorDescription:"Token not found",
                        balance : 0.00,
                        timestamp : Math.floor(new Date().valueOf()),
                        operatorId:req.body.operatorId,
                    }
                    res.status(200).send(resObj);
                }
            })   
        }
    },
    storeUserData :  (req, res, next) => {
        let strBody = req.body;
        req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        req.checkBody("userId", "userId is a mandatory.").notEmpty();
        req.checkBody("userName", "userName mandatory filed.").notEmpty();
        req.checkBody("balance", "balance mandatory filed.").notEmpty();
        var errors = req.validationErrors();
        if (errors) {
            res.status(200).send({"status":false, "message": errors[0].msg });
        } else {
                req.body.balance = req.body.available_balance;
                req.body.playersTokenAtLaunch = req.body.token; 
                let userId = req.body.userId;
                userRequest.findOne({
                    userId: userId
                }, function(err, result) {
                    if(result){
                        userRequest.update({userId:userId}, {$set: req.body},{upsert: true}).then(response => {
                            res.status(200).send({"status":true, "message": "Update" });
                        });                
                    }else{
                        userRequest.create(req.body).then(response => {
                            res.status(200).send({"status":true, "message": "Update" });
                        });                
                    }
                });
        }
    },
    getBalance :  (req, res, next) => {
        let headers = req.headers['signature'];
        let payload = req.body;
        let data = req.body;
        let verification = verifySignature(data, headers);
        payload = JSON.parse(payload);
        if (verification) {
            try {
                userRequest.findOne({
                    userId: payload["userId"]
                }, function(err, result) { 
                    if(result){
                        getLatetsBalance(result).then(balance =>  {
                            let response = {
                                // 'user': payload['user_id'],
                                'status': 'OP_SUCCESS',
                                // 'currency' : 'INR',
                                'balance' : Number(balance.balance.toFixed(2)),
                                // 'request_uuid': payload['request_uuid']
                            }
                            res.json(response)
                        });        
                    }else{
                        let response = {
                            'user': payload['userId'],
                            'status': 'OP_GENERAL_ERROR'
                        }
                        res.json(response)
                    }
                });
            }catch (err) {
                let response = {
                    'user': payload['userId'],
                    'status': 'OP_GENERAL_ERROR'
                }
                res.json(response)
            }
        }else{
            let response = {
                'user': payload['user'],
                'status': 'OP_INVALID_SIGNATURE'
            }
            res.json(response);
        }
    },
    getNewToken : (req, res, next) => {
        req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        req.checkBody("operatorId", "operatorId is a mandatory.").notEmpty();
        req.checkBody("currentToken", "current token mandatory filed.").notEmpty();
        req.checkBody("uid", "uId mandatory filed.").notEmpty();        
        var errors = req.validationErrors();
        if (errors) {
            res.status(200).send({"errorCode":2, "errorDescription": "General" });
        } else {
            userRequest.findOne({
                userId: req.body.uid
            }, function(err, result) {
                if(result){
                    result.operatorId = req.body.operatorId;
                    if(result.token == req.body.currentToken){
                        getLatetsBalance(result).then(balance =>  {
                             let token = Helper.getRandomString(20);    
                             balance.uid = balance.userId;
                             balance.token = token;
                             delete balance.userId;
                             delete balance.nickName;
                             delete balance.currency;
                             result.balance = parseFloat(balance.balance.toFixed(2));
                             result.token =  token;
                             result.save();
                             res.status(200).send(balance);
                        });
                    }else{
                        let resObj = {   
                            errorCode:6,
                            errorDescription:"Token not found"
                        }
                        res.status(200).send(resObj);                            
                    }
                }else{
                    let resObj = {   
                        errorCode:7,
                        errorDescription:"User not found"
                    }
                    res.status(200).send(resObj);
                }
            })
        }
    },
    credit : (req, res, next) => {
        let data = req.body;
         let headers = req.headers['signature'];
         let verification = verifySignature(data, headers);
         //let verification = true;
        let strBody = req.body;
        req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        let generalObj = {
            reqUrl: req.url,
            reqTime: new Date(),
            reqParam: JSON.stringify(req.body),
            reqMethod: req.method,
            reqName: 'credit',
            userId: req.body.userId,
            transactionId : req.body.transactionId,
            roundId : req.body.roundId,
            gameId : req.body.gameId,
            proceedStatus : "open"
        };
        ProviderRequest.create(generalObj);
        GeneralReqResData.create(generalObj);
        // console.log("Credit request++++++++++++++++",req.body);
        //  console.log("Data++++++++++++++++",new Date());
      
        let payload = req.body;
        // let data = JSON.stringify(req.body);
        // verification = true;
        if (verification) {
            try{
                if (payload['creditAmount'] < 0) {
                    response = {
                        'userId': payload['userId'],
                        'status': 'OP_INVALID_AMOUNT'
                    }
                    let errorObj = {
                        reqUrl: req.url,
                        reqTime: new Date(),
                        response: JSON.stringify(response),
                        reqName: 'result',
                        userId: req.body.userId,
                        transactionId : req.body.transactionId,
                        roundId : req.body.roundId,
                        gameId : req.body.gameId,
                        errorCode : response.status
                    }
                    ErrorLog.create(errorObj)
                    return res.json(response);
                }
                else if(payload['gameId'] == ""){
                    response = {
                        'userId': payload['userId'],
                        'status': 'OP_INVALID_PARAMS'
                    }
                    return res.json(response);
                }else{
                    let checkGame = gameList.find(game => game['game_id'] == payload['gameId']); 
                    if(!checkGame){
                        response = {
                            'userId': payload['userId'],
                            'status': 'OP_INVALID_GAME'
                        }
                        let errorObj = {
                            reqUrl: req.url,
                            reqTime: new Date(),
                            response: JSON.stringify(response),
                            reqName: 'bet',
                            userId: req.body.userId,
                            transactionId : req.body.transactionId,
                            roundId : req.body.roundId,
                            gameId : req.body.gameId,
                            errorCode : response.status
                        }
                        ErrorLog.create(errorObj)
                        return res.json(response);
                    }else{
                        req.body.transactionId = req.body.transactionId;
                        getUserByUid(req.body.userId).then(userResult =>  {
                            if(userResult.status == true){
                                payload['whtLblUrl'] =  userResult.data.whtLblUrl;
                                payload['casinoType'] =  checkGame['casinoType'];
                                payload['userName'] =  userResult.data.userName;
                                console.log("payload userName",payload['userName']);
                                console.log("payload casinoType",checkGame['casinoType']);
                                checkPrevTran(req.body.transactionId).then(preTranStatus =>  {
                                    preTranStatus.status = true;
                                    if(preTranStatus.status == false){
                                        getLatetsBalance(payload).then(balance =>  {
                                            let response = {
                                                'userId': payload['userId'],
                                                'status': 'OP_TRANSACTION_NOT_FOUND',
                                                'balance':balance.balance
                                            }
                                              
                                            let errorObj = {
                                                reqUrl: req.url,
                                                reqTime: new Date(),
                                                response: JSON.stringify(response),
                                                reqName: 'bet',
                                                userId: req.body.userId,
                                                transactionId : req.body.transactionId,
                                                roundId : req.body.roundId,
                                                gameId : req.body.gameId,
                                                errorCode : response['status']
                                            }
                                            ErrorLog.create(errorObj)
                                            return res.json(response);       
                                        })
                                    }else{
                                        if(preTranStatus.data.proceedStatus == "rollback"){
                                            payload['userId'] = payload['userId'];
                                            getLatetsBalance(payload).then(balance =>  {
                                                let response = {
                                                    'user': payload['userId'],
                                                    'status': 'OP_ERROR_TRANSACTION_INVALID',
                                                    'request_uuid': payload['request_uuid'],
                                                    'currency' :payload['currency'],
                                                    'errorCode' : 9,
                                                    'timestamp':balance.timestamp,
                                                    'balance' : balance.balance
                                                }
                                                updateRequestFailer(req.body.reference_transaction_uuid,false).then(idemoStatus =>  {
                                                });
                                                return res.json(response)       
                                            })
                                        }else{
                                            checkIdempotentWinGap(req.body.transactionId,req.body.roundId,req.body.creditAmount).then(idemoStatus =>  {
                                                idemoStatus = false;
                                                if(idemoStatus == true){
                                                    getLatetsBalance(payload).then(balance =>  {
                                                        let response = {
                                                            'status': 'OP_DUPLICATE_TRANSACTION',
                                                            'balance':balance.balance
                                                        }
                                                          
                                                        let errorObj = {
                                                            reqUrl: req.url,
                                                            reqTime: new Date(),
                                                            response: JSON.stringify(response),
                                                            reqName: 'credit',
                                                            userId: req.body.userId,
                                                            transactionId : req.body.transactionId,
                                                            roundId : req.body.roundId,
                                                            gameId : req.body.gameId,
                                                            errorCode : response['status']
                                                        }
                                                        ErrorLog.create(errorObj)
                                                        return res.json(response);           
                                                    })
                                                }else{
                                                    let reqAmount = req.body.creditAmount;
                                                    checkTraIdSettle(req.body.transactionId,req.body.reqId).then(tranStatus =>  {
                                                        // result = false;
                                                        if(tranStatus == true){
                                                            getLatetsBalance(payload).then(balance =>  {
                                                                let response = {
                                                                    'status': 'OP_DUPLICATE_TRANSACTION',
                                                                    'balance' : balance.balance
                                                                }
                                                                let errorObj = {
                                                                    reqUrl: req.url,
                                                                    reqTime: new Date(),
                                                                    response: JSON.stringify(response),
                                                                    reqName: 'credit',
                                                                    userId: req.body.userId,
                                                                    transactionId : req.body.transactionId,
                                                                    roundId : req.body.roundId,
                                                                    gameId : req.body.gameId,
                                                                    errorCode : response['status']
                                                                }
                                                                ErrorLog.create(errorObj)
                                                                return res.json(response)       
                                                            })
                                                        }else{
                                                            checkDebitTransaction(req.body.transactionId).then(reqTras =>  {
                                                                generalObj['transactionId'] = req.body.transactionId;
                                                                // console.log("reqTras.status+++++++++++++++",reqTras.status);
                                                                // console.log("req.body.amount+++++++++++++++",req.body.amount);
                                                                if(reqTras.status == true && req.body.creditAmount == 0){
                                                                        getLatetsBalance(payload).then(balance =>  {
                                                                            let response = {
                                                                                'status': 'OP_SUCCESS',
                                                                                'balance' : balance.balance
                                                                            }
                                                                            let errorObj = {
                                                                                reqUrl: req.url,
                                                                                reqTime: new Date(),
                                                                                response: JSON.stringify(response),
                                                                                reqName: 'credit',
                                                                                userId: req.body.userId,
                                                                                transactionId : req.body.transactionId,
                                                                                roundId : req.body.roundId,
                                                                                gameId : req.body.gameId,
                                                                                errorCode : response['status']
                                                                            }
                                                                            ErrorLog.create(errorObj)
                                                                            return res.json(response)       
                                                                        })
                                                                }else{
                                                                    userRequest.findOne({
                                                                        userId: req.body.userId
                                                                    }, function(err, result) {
                                                                        if(result){
                                                                            req.body.amount = (payload['casinoType'] && payload['casinoType'] == "HKD") ? Number(req.body.creditAmount) * 100 : Number(req.body.creditAmount) / 100000;
                                                                            req.body.proccedStatus = preTranStatus.data.proceedStatus;
                                                                            req.body.creditAmount = (payload['casinoType'] && payload['casinoType'] == "HKD") ? Number(req.body.creditAmount) * 100 : req.body.creditAmount;
                                                                            console.log('payload casino amount',req.body.creditAmount);
                                                                            gameOver(req.body,result.whtLblUrl).then(gameRes =>{
                                                                                // console.log("gameRes+++++++++++++",gameRes);
                                                                                if(gameRes.status == true){
                                                                                        getLatetsBalance(payload).then(balance =>  {
                                                                                            // console.log("balance+++++++++++++",balance);
                                                                                            let resp = {
                                                                                                'status': 'OP_SUCCESS',
                                                                                                'balance': balance.balance,
                                                                                            }
                                                                                            generalObj['response'] = JSON.stringify(resp);
                                                                                            generalObj['transactionId'] = req.body.transactionId;
                                                                                            generalObj['request_uuid'] = req.body.reqId;
                                                                                            generalObj['reference_transaction_uuid'] = req.body.transactionId;
                                                                                            generalObj['resTime'] = new Date();
                                                                                            generalObj['round'] = payload['roundId'];
                                                                                            generalObj['amount'] = req.body.creditAmount;
                                                                                            
                                                                                            GeneralReqResData.findOneAndUpdate({
                                                                                                transactionId: req.body.transactionId,
                                                                                                reqName : 'credit'
                                                                                            }, function(err, result) {
                                                                                                if(result){
                                                                                                    result.proceedStatus = "settled";
                                                                                                    result.save();
                                                                                                }else{
                                                                                             
                                                                                                }
                                                                                            }) 
                                                                                            let errorObj = {
                                                                                                reqUrl: req.url,
                                                                                                reqTime: new Date(),
                                                                                                response: JSON.stringify(resp),
                                                                                                reqName: 'credit',
                                                                                                userId: req.body.userId,
                                                                                                transactionId : req.body.transactionId,
                                                                                                roundId : req.body.roundId,
                                                                                                gameId : req.body.gameId,
                                                                                                errorCode :resp['status']
                                                                                            }
                                                                                            ErrorLog.create(errorObj)
                                                                                            // console.log("resp++++++++++++",resp);     
                                                                                            updateRequestFailer(req.body.transactionId,true).then(idemoStatus =>  {
                                                                                            });
                                                                                            //update previous transaction
                                                                                            updatePrevTransaction(req.body.transactionId,'settled').then(updateStatus =>  {
                                                                                                // console.log("updateStatus");
                                                                                            });
            
                                                                                            return res.json(resp);
                                                                                            
                                                                                        })                                           
                                                                                }else{
            
                                                                                    let resp = {
                                                                                        'userId': payload['userId'],
                                                                                        'status': 'OP_GENERAL_ERROR',
                                                                                    }
                                                                                    generalObj['response'] = JSON.stringify(resp);
                                                                                    generalObj['transactionId'] = req.body.transactionId;
                                                                                    generalObj['request_uuid'] = req.body.reqId;
                                                                                    generalObj['reference_transaction_uuid'] = req.body.transactionId;
                                                                                    generalObj['resTime'] = new Date();
                                                                                    generalObj['round'] = payload['roundId'];
                                                                                    generalObj['amount'] = req.body.creditAmount;
                                                                                     
                                                                                    GeneralReqResData.findOneAndUpdate({
                                                                                        transactionId: req.body.transactionId,
                                                                                        reqName : 'credit'
                                                                                    }, function(err, result) {
                                                                                        if(result){
                                                                                            result.proceedStatus = "settled";
                                                                                            result.save();
                                                                                        }else{
                                                                                     
                                                                                        }
                                                                                    })  
                                                                                    let errorObj = {
                                                                                        reqUrl: req.url,
                                                                                        reqTime: new Date(),
                                                                                        response: JSON.stringify(resp),
                                                                                        reqName: 'credit',
                                                                                        userId: req.body.userId,
                                                                                        transactionId : req.body.transactionId,
                                                                                        roundId : req.body.roundId,
                                                                                        gameId : req.body.gameId,
                                                                                        errorCode :resp['status']
                                                                                    }
                                                                                    ErrorLog.create(errorObj)
                                                                                    updateRequestFailer(req.body.transactionId,false).then(idemoStatus =>  {
                                                                                    });
                                                                                    return res.json(resp)
                                                                                }
                                                                            });
                                                                        }else{
                                                                            let resp = {
                                                                                'status': 'OP_USER_NOT_FOUND',
                                                                                'balance': 0,
                                                                            }
                                                                            generalObj['response'] = JSON.stringify(resp);
                                                                            generalObj['transactionId'] = req.body.transactionId;
                                                                            generalObj['reqId'] = req.body.reqId;
                                                                            generalObj['reference_transaction_uuid'] = req.body.transactionId;
                                                                            generalObj['resTime'] = new Date();
                                                                            generalObj['roundId'] = payload['roundId'];
                                                                            generalObj['amount'] = reqAmount;
                                                                             
                                                                            GeneralReqResData.findOneAndUpdate({
                                                                                transactionId: req.body.transactionId,
                                                                                reqName : 'credit'
                                                                            }, function(err, result) {
                                                                                if(result){
                                                                                    result.proceedStatus = "settled";
                                                                                    result.save();
                                                                                }else{
                                                                             
                                                                                }
                                                                            }) 
                                                                            let errorObj = {
                                                                                                reqUrl: req.url,
                                                                                                reqTime: new Date(),
                                                                                                response: JSON.stringify(resp),
                                                                                                reqName: 'credit',
                                                                                                userId: req.body.userId,
                                                                                                transactionId : req.body.transactionId,
                                                                                                roundId : req.body.roundId,
                                                                                                gameId : req.body.gameId,
                                                                                                errorCode :resp['status']
                                                                                            }
                                                                                            ErrorLog.create(errorObj) 
                                                                            updateRequestFailer(req.body.transactionId,false).then(idemoStatus =>  {
                                                                            });
                                                                           
                                                                            return res.json(resp)
                                                                        }
                                                                    });
                                                                }
                                                            });
                                                        }
                                                    })        
                                                }
                                            });
            
                                        }
                                    }
                                });
                            }else{
                                let response = {
                                    'userId': payload['userId'],
                                    'status': 'OP_USER_BLOCKED',
                                }
                                let errorObj = {
                                    reqUrl: req.url,
                                    reqTime: new Date(),
                                    response: JSON.stringify(response),
                                    reqName: 'bet',
                                    userId: req.body.userId,
                                    transactionId : req.body.transactionId,
                                    roundId : req.body.roundId,
                                    gameId : req.body.gameId,
                                    errorCode : response.status
                                }
                                ErrorLog.create(errorObj)
                                return res.json(response);
                            }
                        });
                    }
                }

            }catch (err) {
                // console.log("error+++++++++++",err);
                let response = {
                    'user': payload['user_id'],
                    'status': 'RS_ERROR_UNKNOWN',
                    'request_uuid': payload['request_uuid']
                }
                return res.json(response)
            }
        }else{
            let response = {
                'user': payload['user_id'],
                'status': 'RS_ERROR_INVALID_SIGNATURE',
                'request_uuid': payload['request_uuid']
            }
            return res.json(response);
        }
    },

    debit : (req, res, next) => {
        let data = req.body;
        let headers = req.headers['signature'];
        let verification = verifySignature(data, headers);
         //let verification = true;
        let strBody = req.body;
        req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        // console.log("Data++++++++++++++++",new Date());
        let generalObj = {
            reqUrl: req.url,
            reqTime: new Date(),
            reqParam: JSON.stringify(req.body),
            reqMethod: req.method,
            reqName: 'bet',
            userId: req.body.userId,
            transactionId : req.body.transactionId,
            roundId : req.body.roundId,
            gameId : req.body.gameId
        };
        ProviderRequest.create(generalObj);
        let payload = req.body;
        // let data = JSON.stringify(req.body);
        if (verification) {
            try{
                console.log('verification done');
                if (payload['debitAmount'] < 0) {
                    response = {
                        'userId': payload['userId'],
                        'status': 'OP_ERROR_NEGATIVE_DEBIT_AMOUNT'
                    }
                    let errorObj = {
                        reqUrl: req.url,
                        reqTime: new Date(),
                        response: JSON.stringify(response),
                        reqName: 'bet',
                        userId: req.body.userId,
                        transactionId : req.body.transactionId,
                        roundId : req.body.roundId,
                        gameId : req.body.gameId,
                        errorCode : response.status
                    }
                    ErrorLog.create(errorObj)
                    return res.json(response);
                }else if(payload['gameId'] == ""){
                    response = {
                        'userId': payload['userId'],
                        'status': 'OP_INVALID_PARAMS'
                    }
                    let errorObj = {
                        reqUrl: req.url,
                        reqTime: new Date(),
                        response: JSON.stringify(response),
                        reqName: 'bet',
                        userId: req.body.userId,
                        transactionId : req.body.transactionId,
                        roundId : req.body.roundId,
                        gameId : req.body.gameId,
                        errorCode : response.status
                    }
                    ErrorLog.create(errorObj)
                    return res.json(response);
                }else{
                    let checkGame = gameList.find(game => game['game_id'] == payload['gameId']); 
                    if(!checkGame){
                        response = {
                            'userId': payload['userId'],
                            'status': 'OP_INVALID_GAME'
                        }
                        let errorObj = {
                            reqUrl: req.url,
                            reqTime: new Date(),
                            response: JSON.stringify(response),
                            reqName: 'bet',
                            userId: req.body.userId,
                            transactionId : req.body.transactionId,
                            roundId : req.body.roundId,
                            gameId : req.body.gameId,
                            errorCode : response.status
                        }
                        ErrorLog.create(errorObj)
                        return res.json(response);
                    }else{
                        req.body.gameDetail = checkGame;
                        getUserByToken(req.body.token).then(result =>  {
                            if(result.status == true){                                
                                // getUserByUid(req.body.user).then(userResult =>  {
                                    if(result['data']['userId'] == req.body.userId){
                                        checkTraIdRollback(req.body.transactionId).then(tranStatus => {
                                            if(tranStatus == true){
                                                 getLatetsBalance(result.data).then(balance =>  {
                                                    let response = {
                                                        'userId': payload['userId'],
                                                        'status': 'OP_GENERAL_ERROR',
                                                        'balance':balance.balance
                                                    }
                                                      
                                                    let errorObj = {
                                                        reqUrl: req.url,
                                                        reqTime: new Date(),
                                                        response: JSON.stringify(response),
                                                        reqName: 'bet',
                                                        userId: req.body.userId,
                                                        transactionId : req.body.transactionId,
                                                        roundId : req.body.roundId,
                                                        gameId : req.body.gameId,
                                                        errorCode : "Debit after rollback"
                                                    }
                                                    ErrorLog.create(errorObj)
                                                    return res.json(response); 
                                                })
                                            }else{
                                                if (payload['debitAmount'] == 0) {
                                                    getLatetsBalance(result.data).then(balance =>  {
                                                        let response = {
                                                            'userId': payload['userId'],
                                                            'status': 'OP_ZERO_DEBIT_AMOUNT',
                                                            'balance':balance.balance
                                                        }
                                                        
                                                        let errorObj = {
                                                            reqUrl: req.url,
                                                            reqTime: new Date(),
                                                            response: JSON.stringify(response),
                                                            reqName: 'bet',
                                                            userId: req.body.userId,
                                                            transactionId : req.body.transactionId,
                                                            roundId : req.body.roundId,
                                                            gameId : req.body.gameId,
                                                            errorCode : response.status
                                                        }
                                                        ErrorLog.create(errorObj)
                                                        return res.json(response);   
                                                    }) 
                                                }else{
                                                    checkIdempotentWin(req.body.transactionId,req.body.roundId,req.body.debitAmount).then(idemoStatus =>  {
                                                        if(idemoStatus == true){
                                                            getLatetsBalance(result.data).then(balance =>  {
                                                                let response = {
                                                                    'userId': payload['userId'],
                                                                    'status': 'OP_DUPLICATE_TRANSACTION',
                                                                    'balance' : balance.balance
                                                                }
                                                                let errorObj = {
                                                                    reqUrl: req.url,
                                                                    reqTime: new Date(),
                                                                    response: JSON.stringify(response),
                                                                    reqName: 'bet',
                                                                    userId: req.body.userId,
                                                                    transactionId : req.body.transactionId,
                                                                    roundId : req.body.roundId,
                                                                    gameId : req.body.gameId,
                                                                    errorCode : response.status
                                                                }
                                                                ErrorLog.create(errorObj)
                                                                return res.json(response)       
                                                            })
                                                        }else{
                                                                checkTraId(req.body.transactionId,req.body.reqId).then(tranStatus =>  {
                                                                    if(tranStatus == true){
                                                                        getLatetsBalance(result.data).then(balance =>  {
                                                                            let response = {
                                                                                'userId': payload['userId'],
                                                                                'status': 'OP_DUPLICATE_TRANSACTION',
                                                                                'balance' : balance.balance
                                                                            }
                                                                            let errorObj = {
                                                                                reqUrl: req.url,
                                                                                reqTime: new Date(),
                                                                                response: JSON.stringify(response),
                                                                                reqName: 'bet',
                                                                                userId: req.body.userId,
                                                                                transactionId : req.body.transactionId,
                                                                                roundId : req.body.roundId,
                                                                                gameId : req.body.gameId,
                                                                                errorCode : response.status
                                                                            }
                                                                            ErrorLog.create(errorObj)
                                                                            return res.json(response)       
                                                                        })       
                                                                    }else{
                                                                        console.log("checkGame",checkGame['casinoType']);
                                                                        req.body.debitAmount = (checkGame['casinoType'] && checkGame['casinoType'] == "HKD") ? Number(req.body.debitAmount) * 100 : Number(req.body.debitAmount);
                                                                        console.log('req.body.debitAmount+++++',req.body.debitAmount);
                                                                        if(req.body.debitAmount < 0){
                                                                                response = {
                                                                                    'userId': payload['userId'],
                                                                                    'status': 'OP_ERROR_NEGATIVE_DEBIT_AMOUNT',
                                                                                }
                                                                                let errorObj = {
                                                                                    reqUrl: req.url,
                                                                                    reqTime: new Date(),
                                                                                    response: JSON.stringify(response),
                                                                                    reqName: 'bet',
                                                                                    userId: req.body.userId,
                                                                                    transactionId : req.body.transactionId,
                                                                                    roundId : req.body.roundId,
                                                                                    gameId : req.body.gameId,
                                                                                    errorCode : response.status
                                                                                }
                                                                                ErrorLog.create(errorObj)
                                                                                return res.json(response);      
                                                                        }else{
                                                                            updateTransction(result.data,req.body).then(transData =>{
                                                                                console.log('transData+++++',transData['errorCode']);
                                                                                if(transData.errorCode == 0){
                                                                                    getLatetsBalance(result.data).then(balance =>  {
                                                                                        let response = {
                                                                                            'status': 'OP_SUCCESS',
                                                                                            'balance' : balance.balance,
                                                                                        }
                                                                                        generalObj['response'] = JSON.stringify(response);
                                                                                        generalObj['transactionId'] = req.body['transactionId'];
                                                                                        generalObj['request_uuid'] = req.body['reqId'];
                                                                                        generalObj['resTime'] = new Date();
                                                                                        generalObj['round'] = req.body['roundId'];
                                                                                        generalObj['amount'] = req.body['debitAmount'];
                                                                                        let errorObj = {
                                                                                            reqUrl: req.url,
                                                                                            reqTime: new Date(),
                                                                                            response: JSON.stringify(response),
                                                                                            reqName: 'bet',
                                                                                            userId: req.body.userId,
                                                                                            transactionId : req.body.transactionId,
                                                                                            roundId : req.body.roundId,
                                                                                            gameId : req.body.gameId,
                                                                                            errorCode : response.status
                                                                                        }
                                                                                        ErrorLog.create(errorObj)
        
                                                                                        GeneralReqResData.create(generalObj).then( resData => {
                                                                                        });
                                                                                        return res.json(response)   
                                                                                          
                                                                                    })
                                                                                }else{
                                                                                    if(transData.errorCode == 3){
                                                                                        getLatetsBalance(result.data).then(balance =>  {
                                                                                            let status =transData.errorDescription;
                                                                                            let response = {
                                                                                                'userId': payload['userId'],
                                                                                                'status': status,
                                                                                                'balance' : balance.balance,
                                                                                            }
                                                                                            generalObj['response'] = JSON.stringify(response);
                                                                                            generalObj['transactionId'] = req.body['transactionId'];
                                                                                            generalObj['request_uuid'] = req.body['reqId'];
                                                                                            generalObj['resTime'] = new Date();
                                                                                            generalObj['round'] = req.body['roundId'];
                                                                                            generalObj['amount'] = req.body['debitAmount'];
                                                                                            let errorObj = {
                                                                                                reqUrl: req.url,
                                                                                                reqTime: new Date(),
                                                                                                response: JSON.stringify(response),
                                                                                                reqName: 'bet',
                                                                                                userId: req.body.userId,
                                                                                                transactionId : req.body.transactionId,
                                                                                                roundId : req.body.roundId,
                                                                                                gameId : req.body.gameId,
                                                                                                errorCode : response.status
                                                                                            }
                                                                                            ErrorLog.create(errorObj)
                                                                                            response.status = (response.status=="You are not allow to bet.")?'OP_ACCOUNT_LOCKED': (response.status == "OP_INSUFFICIENT_FUNDS") ? "OP_INSUFFICIENT_FUNDS" : "OP_GENERAL_ERROR";
                                                                                            GeneralReqResData.create(generalObj).then( resData => {
                                                                                            });
                                                                                            return res.json(response)    
                                                                                        });
                                                                                    }else{
                                                                                        response = {
                                                                                            'user': payload['userId'],
                                                                                            'status': 'OP_GENERAL_ERROR'
                                                                                        }
                                                                                        generalObj['response'] = JSON.stringify(response);
                                                                                        generalObj['transactionId'] = req.body['transactionId'];
                                                                                        generalObj['request_uuid'] = req.body['reqId'];
                                                                                        generalObj['resTime'] = new Date();
                                                                                        generalObj['round'] = req.body['roundId'];
                                                                                        generalObj['amount'] = req.body['debitAmount'];
                                                                                        let errorObj = {
                                                                                            reqUrl: req.url,
                                                                                            reqTime: new Date(),
                                                                                            response: JSON.stringify(response),
                                                                                            reqName: 'bet',
                                                                                            userId: req.body.userId,
                                                                                            transactionId : req.body.transactionId,
                                                                                            roundId : req.body.roundId,
                                                                                            gameId : req.body.gameId,
                                                                                            errorCode : response.status
                                                                                        }
                                                                                        ErrorLog.create(errorObj)
                                                                                        response.status = (response.status=="You are not allow to bet.")?'OP_ACCOUNT_LOCKED':'OP_GENERAL_ERROR'
                                                                                        GeneralReqResData.create(generalObj).then( resData => {
                                                                                        });
                                                                                        return res.json(response);
                                                                                    }
                                                                                }
                                                                                })
                                                                            }
                                                                    }
                                                                });
                                                            }
                                                        });
                                                }
                                            }
                                        }) 
                                    }else{
                                        let response = {
                                            'UserId': payload['user_id'],
                                            'status': 'OP_USER_DISABLED',
                                        }
                                        let errorObj = {
                                            reqUrl: req.url,
                                            reqTime: new Date(),
                                            response: JSON.stringify(response),
                                            reqName: 'bet',
                                            userId: req.body.userId,
                                            transactionId : req.body.transactionId,
                                            roundId : req.body.roundId,
                                            gameId : req.body.gameId,
                                            errorCode : response.status
                                        }
                                        ErrorLog.create(errorObj)
                                        return res.json(response);   
                                    }
                                // });
                            }else{
                                      let response = {
                                        'userId': payload['userId'],
                                        'status': 'OP_TOKEN_NOT_FOUND',
                                    }
                                    let errorObj = {
                                        reqUrl: req.url,
                                        reqTime: new Date(),
                                        response: JSON.stringify(response),
                                        reqName: 'bet',
                                        userId: req.body.userId,
                                        transactionId : req.body.transactionId,
                                        roundId : req.body.roundId,
                                        gameId : req.body.gameId,
                                        errorCode : response.status
                                    }
                                    ErrorLog.create(errorObj)
                                    return res.json(response);
                                    
                            }
                        });
                    }
                }
            }catch (err) {
           
            }
        }else{
            let response = {
                'user': payload['userId'],
                'status': 'OP_INVALID_SIGNATURE',
            }
            let errorObj = {
                reqUrl: req.url,
                reqTime: new Date(),
                response: JSON.stringify(response),
                reqName: 'bet',
                userId: req.body.userId,
                transactionId : req.body.transactionId,
                roundId : req.body.roundId,
                gameId : req.body.gameId,
                errorCode : response.status
            }
            ErrorLog.create(errorObj)
            return res.json(response);
        }
     },

    rollback : (req, res, next) => {
        let data = req.body;
        let headers = req.headers['signature'];
        //let verification = verifySignature(data, headers);
        let verification = true;
        let strBody = req.body;
        req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        // console.log("Data++++++++++++++++",new Date());
        let generalObj = {
            reqUrl: req.url,
            reqTime: new Date(),
            reqParam: JSON.stringify(req.body),
            reqMethod: req.method,
            reqName: 'rollback',
            userId: req.body.userId,
            transactionId : req.body.transactionId,
            roundId : req.body.roundId,
            gameId : req.body.gameId
        };
        ProviderRequest.create(generalObj);
        let payload = req.body;
        // let data = JSON.stringify(req.body);
        setTimeout(() => {
            if (verification) {
                try{
                    if(payload['gameId'] == ""){
                        response = {
                            'userId': payload['userId'],
                            'status': 'OP_INVALID_PARAMS'
                        }
                        return res.json(response);
                    }else{
                        let checkGame = gameList.find(game => game['game_id'] == payload['gameId']); 
                        if(!checkGame){
                            response = {
                                'userId': payload['userId'],
                                'status': 'OP_INVALID_GAME'
                            }
                            let errorObj = {
                                reqUrl: req.url,
                                reqTime: new Date(),
                                response: JSON.stringify(response),
                                reqName: 'bet',
                                userId: req.body.userId,
                                transactionId : req.body.transactionId,
                                roundId : req.body.roundId,
                                gameId : req.body.gameId,
                                errorCode : response.status
                            }
                            ErrorLog.create(errorObj)
                            return res.json(response);
                        }else{
                            req.body.transactionId = req.body.transactionId;
                            // getUserByToken(req.body.token).then(result =>  {
                            //     if(result.status == true){
                                    getUserByUid(req.body.userId).then(result =>  {
                                        if(result.status == true){
                                            payload['whtLblUrl'] =  result.data.whtLblUrl;
                    
                                            // checkRollbackTransaction(req.body.reference_transaction_uuid).then(preTranStatusCredit =>  {
                                            //     if(preTranStatusCredit.status == true){
                                            //         payload['userId'] = payload['user_id'];
                                            //         getLatetsBalance(payload).then(balance =>  {
                                            //             let response = {
                                            //                 'user': payload['user_id'],
                                            //                 'status': 'RS_ERROR_DUPLICATE_TRANSACTION',
                                            //                 'request_uuid': payload['request_uuid'],
                                            //                 'currency' :payload['currency'],
                                            //                 'errorCode' : 0,
                                            //                 'timestamp':balance.timestamp,
                                            //                 'balance' : balance.balance
                                            //             }
                                            //             response.currency = payload['currency'];
                                            //             res.json(response)       
                                            //         })
                                            //     }else{
                                                    
                                            //     }
                                            // }); 
                                            checkPrevTran(req.body.transactionId).then(idempotentStatus =>  {
                                                if(idempotentStatus.status == false){
                                                    getLatetsBalance(result.data).then(balance =>  {
                                                        let response = {
                                                            'userId': payload['userId'],
                                                            'status': 'OP_TRANSACTION_NOT_FOUND',
                                                            'balance':balance.balance
                                                        }
                                                          
                                                        let errorObj = {
                                                            reqUrl: req.url,
                                                            reqTime: new Date(),
                                                            response: JSON.stringify(response),
                                                            reqName: 'rollback',
                                                            userId: req.body.userId,
                                                            transactionId : req.body.transactionId,
                                                            roundId : req.body.roundId,
                                                            gameId : req.body.gameId,
                                                            errorCode : response.status
                                                        }
                                                        ErrorLog.create(errorObj)
                                                        return res.json(response); 
                                                    })
            
                                                }else{
                                                    checkIdempotentRollback(req.body.transactionId,req.body.roundId,req.body.transactionId).then(idemoStatus =>  {
                                                        if(idemoStatus == true){
                                                            getLatetsBalance(result.data).then(balance =>  {
                                                                let response = {
                                                                    'userId': payload['userId'],
                                                                    'status': 'OP_DUPLICATE_TRANSACTION',
                                                                    'balance':balance.balance
                                                                }
                                                                  
                                                                let errorObj = {
                                                                    reqUrl: req.url,
                                                                    reqTime: new Date(),
                                                                    response: JSON.stringify(response),
                                                                    reqName: 'rollback',
                                                                    userId: req.body.userId,
                                                                    transactionId : req.body.transactionId,
                                                                    roundId : req.body.roundId,
                                                                    gameId : req.body.gameId,
                                                                    errorCode : response.status
                                                                }
                                                                ErrorLog.create(errorObj)
                                                                return res.json(response); 
                                                            })
                                                        }else{
                                                            updateTransctionRollback(result.data,req.body).then(transData =>{
                                                                if(transData.errorCode == 0){
                                                                    getLatetsBalance(result.data).then(balance =>  {
                                                                        // console.log("balance++++++++++",balance);
                                                                        let response = {
                                                                            'user': payload['userId'],
                                                                            'errorCode' : 0,
                                                                            'timestamp':balance.timestamp,
                                                                            'token':payload['token'],
                                                                            'status': 'OP_SUCCESS',
                                                                            'balance' : balance.balance,
                                                                            'request_uuid': payload['reqId'],
                                                                            'round' : payload['roundId'],
                                                                            'transactionId':payload['transactionId']
                                                                        }
                                                                        generalObj['response'] = JSON.stringify(response);
                                                                        generalObj['transactionId'] = req.body.transactionId;
                                                                        generalObj['request_uuid'] = req.body.reqId;
                                                                        generalObj['resTime'] = new Date();
                                                                        generalObj['round'] = payload['roundId'];
                                                                        generalObj['transactionId'] = payload['transactionId'];
                                                                        GeneralReqResData.create(generalObj);
                                                                        updateRequestFailer(req.body.transactionId,true).then(idemoStatus =>  {
                                                                        });
                                                                        updatePrevTransaction(req.body.transactionId,'rollback').then(updateStatus =>  {
                                                                        });
                                                                        let errorObj = {
                                                                            reqUrl: req.url,
                                                                            reqTime: new Date(),
                                                                            response: JSON.stringify(response),
                                                                            reqName: 'rollback',
                                                                            userId: req.body.userId,
                                                                            transactionId : req.body.transactionId,
                                                                            roundId : req.body.roundId,
                                                                            gameId : req.body.gameId,
                                                                            errorCode :response['status']
                                                                        }
                                                                        ErrorLog.create(errorObj) 
                                                                        let resObj = {
                                                                            status : "OP_SUCCESS",
                                                                            balance: balance.balance
                                                                        }
                                                                        return res.json(resObj)      
                                                                    })
                                                                }else{
                                                                    if(transData.errorCode == 3){
                                                                        let response = {
                                                                            'status': transData['errorDescription']
                                                                        }
                                                                        updateRequestFailer(req.body.transactionId,false).then(idemoStatus =>  {
                                                                        });
                                                                        let errorObj = {
                                                                            reqUrl: req.url,
                                                                            reqTime: new Date(),
                                                                            response: JSON.stringify(response),
                                                                            reqName: 'rollback',
                                                                            userId: req.body.userId,
                                                                            transactionId : req.body.transactionId,
                                                                            roundId : req.body.roundId,
                                                                            gameId : req.body.gameId,
                                                                            errorCode :response['status']
                                                                        }
                                                                        ErrorLog.create(errorObj) 
                                                                        return res.json(response);   
                                                                    }else{
                                                                        let response = {
                                                                            'status': 'OP_GENERAL_ERROR'
                                                                        }
                                                                        updateRequestFailer(req.body.transactionId,false).then(idemoStatus =>  {
                                                                        });
                                                                        let errorObj = {
                                                                            reqUrl: req.url,
                                                                            reqTime: new Date(),
                                                                            response: JSON.stringify(response),
                                                                            reqName: 'rollback',
                                                                            userId: req.body.userId,
                                                                            transactionId : req.body.transactionId,
                                                                            roundId : req.body.roundId,
                                                                            gameId : req.body.gameId,
                                                                            errorCode :response['status']
                                                                        }
                                                                        ErrorLog.create(errorObj) 
                                                                        return res.json(response);   
                                                                    }
                                                                }
                                                            })   
                                                         }
                                                    });
                                                }
                                            });
                                            
                                            
                                        }else{
                                            let response = {
                                                'status': 'OP_USER_NOT_FOUND',
                                            }
                                            updateRequestFailer(req.body.transactionId,false).then(idemoStatus =>  {
                                            });
                                            let errorObj = {
                                                reqUrl: req.url,
                                                reqTime: new Date(),
                                                response: JSON.stringify(response),
                                                reqName: 'rollback',
                                                userId: req.body.userId,
                                                transactionId : req.body.transactionId,
                                                roundId : req.body.roundId,
                                                gameId : req.body.gameId,
                                                errorCode :response['status']
                                            }
                                            ErrorLog.create(errorObj) 
                                            return res.json(response);   
                                        }
                                    });
                            //     }else{
                            //         let response = {
                            //             'status': 'OP_TOKEN_NOT_FOUND',
                            //         }
                            //         let errorObj = {
                            //             reqUrl: req.url,
                            //             reqTime: new Date(),
                            //             response: JSON.stringify(response),
                            //             reqName: 'rollback',
                            //             userId: req.body.userId,
                            //             transactionId : req.body.transactionId,
                            //             roundId : req.body.roundId,
                            //             gameId : req.body.gameId,
                            //             errorCode :response['status']
                            //         }
                            //         ErrorLog.create(errorObj) 
                            //         return res.json(response);
                            //     }
                            // });
                        }
                    }
                }catch (err) {
                    // console.log("error+++++++++++++++",err);
                }
            }else{
                let response = {
                    'status': 'OP_INVALID_SIGNATURE'
                }
                updateRequestFailer(req.body.reference_transaction_uuid,false).then(idemoStatus =>  {
                });
                let errorObj = {
                    reqUrl: req.url,
                    reqTime: new Date(),
                    response: JSON.stringify(response),
                    reqName: 'rollback',
                    userId: req.body.userId,
                    transactionId : req.body.transactionId,
                    roundId : req.body.roundId,
                    gameId : req.body.gameId,
                    errorCode :response['status']
                }
                ErrorLog.create(errorObj) 
                return res.json(response);
            }       
        }, 2000);
    },
    rollbackUnchecked : (req, res, next) => {
        let data = req.body;
        let headers = req.headers['casino-signature'];
        //let verification = verifySignature(data, headers);
        let verification = true;
        let strBody = req.body;
        req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        let generalObj = {
            reqUrl: req.url,
            reqTime: new Date(),
            reqParam: JSON.stringify(req.body),
            reqMethod: req.method,
            reqName: 'rollback',
            userId: req.body.user,
            transactionId : req.body.reference_transaction_uuid
        };
        ProviderRequest.create(generalObj);
        let payload = req.body;
        payload["user_id"] = payload["user"];
        // let data = JSON.stringify(req.body);
        verification = true;
        setTimeout(() => {
            if (verification) {
                try{
                    req.body.transactionId = req.body.request_uuid;
                    getUserByToken(req.body.token).then(result =>  {
                        result.status = true;
                        if(result.status == true){
                            getUserByUid(req.body.user).then(userResult =>  {
                                userResult.status = true;
                                if(userResult.status == true){
                                    payload['whtLblUrl'] =  userResult.data.whtLblUrl;
            
                                    // checkRollbackTransaction(req.body.reference_transaction_uuid).then(preTranStatusCredit =>  {
                                    //     if(preTranStatusCredit.status == true){
                                    //         payload['userId'] = payload['user_id'];
                                    //         getLatetsBalance(payload).then(balance =>  {
                                    //             let response = {
                                    //                 'user': payload['user_id'],
                                    //                 'status': 'RS_ERROR_DUPLICATE_TRANSACTION',
                                    //                 'request_uuid': payload['request_uuid'],
                                    //                 'currency' :payload['currency'],
                                    //                 'errorCode' : 0,
                                    //                 'timestamp':balance.timestamp,
                                    //                 'balance' : balance.balance
                                    //             }
                                    //             response.currency = payload['currency'];
                                    //             res.json(response)       
                                    //         })
                                    //     }else{
                                            
                                    //     }
                                    // }); 
                                    checkPrevTran(req.body.reference_transaction_uuid).then(idempotentStatus =>  {
                                        idempotentStatus = true;
                                        if(idempotentStatus.status == false){
                                            payload['userId'] = payload['user_id'];
                                            getLatetsBalance(payload).then(balance =>  {                                                    
                                                let response = {
                                                    'user': payload['user_id'],
                                                    'status': 'RS_OK',
                                                    'request_uuid': payload['request_uuid'],
                                                    'currency' :payload['currency'],
                                                    'errorCode' : 0,
                                                    'timestamp':balance.timestamp,
                                                    'balance' : balance.balance
                                                }
                                                response.currency = payload['currency'];
                                                updateRequestFailer(req.body.reference_transaction_uuid,false).then(idemoStatus =>  {
                                                });
                                                return res.json(response)       
                                            })
                                        }else{
                                            checkIdempotentRollback(req.body.transaction_uuid,req.body.round,req.body.reference_transaction_uuid).then(idemoStatus =>  {
                                                idemoStatus = false;
                                                if(idemoStatus == true){
                                                    getLatetsBalance(result.data).then(balance =>  {
                                                        let response = {
                                                            'user': payload['user_id'],
                                                            'status': 'RS_OK',
                                                            'request_uuid': payload['request_uuid'],
                                                            'currency' :payload['currency'],
                                                            'errorCode' : 0,
                                                            'timestamp':balance.timestamp,
                                                            'balance' : balance.balance
                                                        }
                                                        response.currency = payload['currency'];
                                                        updateRequestFailer(req.body.reference_transaction_uuid,false).then(idemoStatus =>  {
                                                        });
                                                        return res.json(response)       
                                                    })
                                                }else{
                                                    checkTraId(req.body.transaction_uuid,req.body.request_uuid).then(tranStatus =>  {
                                                        tranStatus = false;
                                                        if(tranStatus == true){
                                                            getLatetsBalance(result.data).then(balance =>  {
                                                                let response = {
                                                                    'user': payload['user_id'],
                                                                    'status': 'RS_ERROR_DUPLICATE_TRANSACTION',
                                                                    'request_uuid': payload['request_uuid'],
                                                                    'currency' :payload['currency'],
                                                                    'errorCode' : 0,
                                                                    'timestamp':balance.timestamp,
                                                                    'balance' : balance.balance
                                                                }
                                                                response.currency = payload['currency'];
                                                                updateRequestFailer(req.body.reference_transaction_uuid,false).then(idemoStatus =>  {
                                                                });
                                                                return res.json(response)       
                                                            })
                                                        }else{
                                                            updateTransctionRollback(result.data,req.body).then(transData =>{
                                                                if(transData.errorCode == 0){
                                                                    getLatetsBalance(result.data).then(balance =>  {
                                                                        // console.log("balance++++++++++",balance);
                                                                        let response = {
                                                                            'currency' :payload['currency'],
                                                                            'user': payload['user'],
                                                                            'errorCode' : 0,
                                                                            'timestamp':balance.timestamp,
                                                                            'token':payload['token'],
                                                                            'status': 'RS_OK',
                                                                            'balance' : balance.balance,
                                                                            'request_uuid': payload['request_uuid'],
                                                                            'round' : payload['round'],
                                                                            'transactionId':payload['supplier_transaction_id']
                                                                        }
                                                                        generalObj['response'] = JSON.stringify(response);
                                                                        generalObj['transactionId'] = req.body.transaction_uuid;
                                                                        generalObj['request_uuid'] = req.body.request_uuid;
                                                                        generalObj['resTime'] = new Date();
                                                                        generalObj['round'] = payload['round'];
                                                                        generalObj['reference_transaction_uuid'] = payload['reference_transaction_uuid'];
                                                                        GeneralReqResData.create(generalObj);
                                                                        updateRequestFailer(req.body.reference_transaction_uuid,true).then(idemoStatus =>  {
                                                                        });
                                                                        updatePrevTransaction(req.body.reference_transaction_uuid,'rollback').then(updateStatus =>  {
                                                                        });
                                                                        return res.json(response)      
                                                                    })
                                                                }else{
                                                                    response = {
                                                                        'user': payload['user_id'],
                                                                        'status': 'RS_ERROR_UNKNOWN',
                                                                        'request_uuid': payload['request_uuid']
                                                                    }
                                                                    updateRequestFailer(req.body.reference_transaction_uuid,false).then(idemoStatus =>  {
                                                                    });
                                                                    response.currency = payload['currency'];
                                                                    return res.json(response);    
                                                                }
                                                            })
                                                        }
                                                    });   
                                                 }
                                            });
                                        }
                                    });
                                    
                                    
                                }else{
                                    let response = {
                                        'user': payload['user_id'],
                                        'status': 'RS_ERROR_USER_DISABLED',
                                        'request_uuid': payload['request_uuid']
                                    }
                                    response.currency = payload['currency'];
                                    updateRequestFailer(req.body.reference_transaction_uuid,false).then(idemoStatus =>  {
                                    });
                                    return res.json(response);    
                                }
                            });
                        }else{
                            let response = {
                                'user': payload['user_id'],
                                'status': 'RS_ERROR_INVALID_TOKEN',
                            }
                            return res.json(response);
                        }
                    });
                }catch (err) {
                    // console.log("error+++++++++++++++",err);
                }
            }else{
                let response = {
                    'user': payload['user_id'],
                    'status': 'RS_ERROR_INVALID_SIGNATURE'
                }
                updateRequestFailer(req.body.reference_transaction_uuid,false).then(idemoStatus =>  {
                });
                return res.json(response);
            }       
        }, 2000);
    },
    reSettle: (req, res, next) => {
        try {
            req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
        } catch (err) {
           res.json({ 'error': 'Unauthorised Access' })
         }
    },
    getUnsettledBet : (req, res, next) => {
            try {
                req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
                GeneralReqResData.findOne({
                    transactionId:req.body.casino_bet_id,
                    reqName : {$ne : "bet"}
                }, function(err, result) {
                    if(result){
                        if(result['reqUrl'] == "/resultrequest"){
                            console.log('result++++++++',result);
                            settledUnsettledResult(result).then(resultData =>  {
                                return res.json(resultData)  
                            })
                        }else if(result['reqUrl'] == "/rollbackrequest"){
                            rollbackUnsettledResult(result).then(resultData =>  {
                                console.log('resultData++++++++',resultData);
                                return res.json(resultData)  
                            })
                        }
                    }else{
                        let resultData = {
                            'status': false,
                            'data': []
                        }
                        return res.json(resultData) 
                    }
                });
            }catch(err){
                console.log('err++++++');
                res.send({"status": true,data : []})
            }
    },

    gameList : (req, res, next) => {
        try {
            req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            // let payload = jwt.decode(req.headers['x-casino-signature'])
           // let payload = {"\partner_id\":+req.body.partner_id};
           let data = {partner_id:req.body.partnerId};
        //    data = {partner_id: req.body.partner_id};
        //    return false;
           data = JSON.stringify(data);
                 // var data = JSON.stringify(payload);
            let url = 'http://stg.dreamcasino.live/games/list'
            //let url = 'https://api.dreamcasino.live/games/list';
            var ip = require("ip");
            let currentIp = ip.address();
            let sign = createSignature(data);
            var config = {
              method: 'post',
              url: url,
              headers: {
                'casino-signature': sign,
                'Content-Type': 'application/json',
              },
              data: data
            };
            axios(config)
              .then(function (response) {
                Redisclient.set("sm_dream_casino_list", JSON.stringify(response.data));
                res.json(response.data);
              }).catch(function (error) {
                // handle error
                // console.log("error+++++++++++++",error);
              })
            // res.json(JSON.parse(response.text))
          } catch (err) {
            res.json({ 'error': 'Unauthorised Access' })
          }
    },
    gameListRedis : (req, res, next) => {
        // let bodyData = JSON.parse(req.body);
        // let product = bodyData.product;
        // console.log(product);
        Redisclient.get("smdcnew_live", function(err, reply) {
            if(reply){
                reply = JSON.parse(reply);
                //dream_casino_list_stag
                // let filtered_array  = reply.map(user => _.pick(user,['name', 'game_id','url_thumb','category']))
                // let allGame = [
                //     '6509','6510','6511','6512','6513','6514','6515','11598','12834',
                //     '9511','9512','9513','9514','9515','9516','9765','10729','11421','11422','11423','11424','11425','11426','11427','12511','12512','12513','12514','12515','12516','12662','12663',
                //     "3897","3898","3899","3900","3901","3902","3905","3906","3907","3908","3909","3910","3911","3912","3913","3914","3915","3916",
                //     "3917","3918","3919","3920","3921","3922","3923","3924","3925","3926","3927","3928","3929","3997","3998","3999","4001","4002",
                //     "4089","4090", "6487","6602","6943","7310","8078","8625","8627","9748","9750","9752","10354","10356","10358","10365","10369","10677",
                //     "11010","11012","11640","12808","12812","13932"      
                //   ]
                // let filtered_array_res = _.filter(
                //     reply, function(o) {
                //         let checkInc = _.includes(allGame,String(o.game_id))
                //         if(checkInc){
                //             return o;
                //         }
                //     }
                // );
                //  console.log(filtered_array_res);
                // Redisclient.set("sm_dream_casino_list_with_zero",JSON.stringify(filtered_array_res)) 
                let resultObj = {
                    status : true,
                    data : reply
                }
                res.status(200).send(resultObj);
            }else{
                let resultObj = {
                    status : false,
                    data : []
                }
                res.status(200).send(resultObj);
            }  
        });
    },
    saveGameList: (req, res, next) => {
        Redisclient.set("smdcnew_live", JSON.stringify(gameListJson));
        res.status(200).send({"status":true})
    },
    gameUrl : (req, res, next) => {
        try {

            // let payload = jwt.decode(req.headers['x-casino-signature'])
            let payload = JSON.parse(req.body);
            console.log('payload',payload); 
            let whtLblUrl = payload['whtLblUrl'];
            let userName = payload['userName'];
            delete payload['whtLblUrl'];
            delete payload['userName'];
            payload['partner_id'] = payload['partnerId'];
            payload['country'] = 'IN';
            let token = Helper.getRandomString(20);
            payload['token'] = token;
            payload['lang'] = 'en';
            payload['ip'] = "198.244.201.143";
            let data = JSON.stringify(payload);
           let url = 'https://dev-api.dreamdelhi.com/games/url';
          //let url = 'https://api.dreamcasino.live/games/url';
        //   console.log('nicher');
        //   console.log('url++++++',url);
            let sign = createSignature(data)
            // console.log('sign+++++++++',sign);
            // console.log(`signature for ${data} is '${sign}'"`);
            var config = {
              method: 'post',
              url: url,
              headers: {
                'casino-signature': sign,
                'Content-Type': 'application/json',
              },
              data: JSON.parse(data)
            };
            // console.log('config++++++',config);
            axios(config)
              .then(function (response) {
                // console.log('gameUrl Response++++++++',response);
                let userId = payload['user'];
                let obj = {
                    balance : 0,
                    token : token,
                    whtLblUrl : whtLblUrl,
                    userName : userName,
                    userId : userId ,
                    playersTokenAtLaunch : Helper.getRandomString(20),
                } 
                userRequest.findOne({
                    userId: userId
                }, function(err, result) {
                    if(result){
                        userRequest.updateMany({userId:userId}, {$set: obj},{upsert: true}).then(response => {
                            // console.log("updated user",obj.userName);
                        });                
                    }else{
                        userRequest.create(obj).then(response => {
                            // console.log("created user",obj.userName);
                        });                
                    }
                });
                res.json(response.data);
              }) .catch(function (error) {
                // console.log('error+++++++++',error);
                res.json({ 'error': 'Unauthorised Access' })
                // handle error
              })
          } catch (err) {
            res.json({ 'error': 'Unauthorised Access' })
          }
    },
    login: (req, res, next) => {
        try {
            // let payload = jwt.decode(req.headers['x-casino-signature'])
            let payload = JSON.parse(req.body);
            let whtLblUrl = payload['whtLblUrl'];
            let userName = payload['username'];
            let casinoType = (payload['casinoType'])?payload['casinoType']:"INR";
            // payload['partner_id'] = payload['partnerId'];
            payload['country'] = 'IN';
            let token = Helper.getRandomString(20);
            payload['token'] = token;
            payload['clientIp'] = "198.244.201.143";
            let url = 'https://api.dreamdelhi.com/api/operator/login';
           //let url = 'https://dev-api.dreamdelhi.com/api/operator/login';
          //let url = 'https://api.dreamcasino.live/games/url';
          getLatetsBalance(payload).then(balance =>  {
            delete payload['whtLblUrl'];
            //delete payload['username'];
            delete payload['country'];
            delete payload['token'];
            delete payload['lang'];
            delete payload['casinoType'];
            payload['balance'] = balance.balance;
            payload['redirectUrl'] = "https://server.betfair.cx/"; 
            let data = JSON.stringify(payload);
                let sign = createSignature(data)
                // console.log(`signature for ${data} is '${sign}'"`);
                var config = {
                  method: 'post',
                  url: url,
                  headers: {
                    'Signature': sign,
                    'Content-Type': 'application/json',
                  },
                  data: payload
                };    
                // console.log('config+++++',config);            
                axios(config)
                  .then(function (response) {
                    let resData = JSON.parse(JSON.stringify(response.data));
                    let userId = payload['userId'];
                    let obj = {
                        balance : 0,
                        token : resData['token'],
                        whtLblUrl : whtLblUrl,
                        userName : userName,
                        userId : payload['userId'] ,
                        playersTokenAtLaunch : Helper.getRandomString(20),
                        casinoType : casinoType
                    } 
                    // console.log('obj+++++++++',obj);
                    userRequest.count({
                        userId: userId
                    }, function(err, result) {                         
                        if(result > 0){ 
                            userRequest.updateMany({userId:userId}, {$set: obj},{upsert: true}).then(response => {
                                // console.log("updated user",obj.userName);
                            });                
                        }else{
                            userRequest.create(obj).then(response => {
                                // console.log("created user",obj.userName);
                            });                
                        }
                    });
                    res.json(response.data);
                  }) .catch(function (error) {
                    //  console.log('error+++++++++',error);
                    res.json({ 'error': 'Unauthorised Access' })
                    // handle error
                  })
          });       
          } catch (err) {
            res.json({ 'error': 'Unauthorised Access' })
          }
    },
    getRecord : (req, res, next) => {
        req.body = JSON.parse(req.body);
        var today = new Date();
        var fifteenDaysAgo = new Date(today.getTime() - (16 * 24 * 60 * 60 * 1000));
        let findQury = {"reqName" : req.body.reqName,reqTime : {$gte: fifteenDaysAgo}};
        userRequest.find({}, function(err, userDocs) {
            let userData = JSON.parse(JSON.stringify(userDocs));
            GeneralReqResData.find(findQury, function(err, docs) {
                if (docs) {
                    let finalData = JSON.parse(JSON.stringify(docs));
                    let tranIdAry = [];
                    let i = 0;
                    let totalData = finalData.length;
                    async.eachSeries(finalData, function (data, next){
                        tranIdAry.push(data['reference_transaction_uuid']);
                        i = i + 1;
                        if(i == totalData){
                            GeneralReqResData.find({ transactionId: { $in: tranIdAry } }, (err, docsData) => {
                                let betData = JSON.parse(JSON.stringify(docsData));
                                let j = 0;
                                let totalRollback = betData.length;
                                let printedData = [];
                                async.eachSeries(betData, function (dataInner, nextInner){
                                    j = j + 1;
                                    let rollbackData = _.find(finalData, { reference_transaction_uuid: dataInner['transactionId'] });
                                    if(rollbackData){
                                        let findUserName = _.find(userData, { userId : dataInner['userId'] });
                                        let obj = {
                                            reqUrl : rollbackData['reqUrl'],
                                            userId : rollbackData['userId'],
                                            userName : (findUserName)?findUserName['userName']:'',
                                            amount : Number(dataInner['amount'])/100000,
                                            reqTime : rollbackData['reqTime'],
                                            transactionId : rollbackData['transactionId'],
                                            request_uuid : rollbackData['request_uuid'],
                                            round : rollbackData['round'],
                                        }    
                                        printedData.push(obj);
                                        nextInner();
                                        if(j == totalRollback){
                                                const xls = json2xls(printedData);
                                                fs.writeFileSync('output.xlsx', xls, 'binary');
                                        }
                                    }else{
                                        nextInner();
                                        if(j == totalRollback){
                                            const xls = json2xls(printedData);
                                            fs.writeFileSync('output.xlsx', xls, 'binary');
                                        }
                                    }
                                })
                            });
                        }
                        next();
                    })
                    let resultObj = {
                        status : true,
                        data : []
                    }
                    res.status(200).send(resultObj);
                    //const xls = json2xls(finalData);
                    //fs.writeFileSync('output.xlsx', xls, 'binary');
    
                }
            });
    
        })
    }
}; 

function createSignature(data) {
    let sign = crypto.createSign('SHA256');
    sign.write(data);
    sign.end();
    const key = fs.readFileSync(private_keyPath, "utf8");;
    let sign_str = sign.sign(key, 'base64');
    return sign_str;
}

function verifySignature(data, sign) {    
    const pubkey = fs.readFileSync(public_keyPath, "utf8");
    let verifier = crypto.createVerify('SHA256');
    verifier.update(data);
    return verifier.verify(pubkey, sign, 'base64');
}

function getLatetsBalance(result) {
    return new Promise((resolve, reject) => {
        console.log('result.userName',result['userName']);
        console.log('result.data.casinoType',result['casinoType']);
        var requestArray = {
            method: 'GET',
            // body: bodyData,
            headers: {
                'Content-Type': 'application/json',
            },
            dataType: 'json'
        };
        let url = result.whtLblUrl + "user/getBalanceStudio/" + result.userId;
         //let url =   "http://localhost:7474/api/v1/user/getBalanceStudio/" + result.userId;
        requestify.request(url, requestArray)
            .then(function(response) {
                if (response.getCode() == 200) {
                    var response = JSON.parse((response.body));
                    if(response.status == true){
                        let balance =response.data.available_balance - Math.abs(response.data.casino_exposer);
                        let resObj = {
                            uid : result.userId,
                            nickName : response.data.userName,
                            //balance : Number((Number(balance) * 100000).toFixed(2)),
                            balance : (result['casinoType'] && result['casinoType'] == "HKD") ? Number((Number(balance) / 100).toFixed(2))  : Number(Number(balance).toFixed(2)), 
                            status : "OP_SUCCESS", 
                            timestamp : Math.floor(new Date().valueOf())
                        } 
                        resolve(resObj);
                    }else{
                        let resObj = {   
                            errorCode:7,
                            errorDescription:"User Not Found"
                        }
                        resolve(resObj);
                    }
                }else{
                    let resObj = {   
                        errorCode:7,
                        errorDescription:"User Not Found"
                    }
                    resolve(resObj);
                }
            }).catch(err => {
                //console.log(err);
            });
    })
}

function getUserByToken(token){
    return new Promise((resolve, reject) => {
        userRequest.findOne({
            token: token
        }, function(err, result) {
            if(result){
                resolve({status:true,data:result})
            }else{
                resolve({status:false})
            }
        });
    })
}

function getUserByUid(uid){
    return new Promise((resolve, reject) => {
        userRequest.findOne({
            userId: uid
        }, function(err, result) {
            if(result){
                resolve({status:true,data:result})
            }else{
                resolve({status:false})
            }
        });
    })
}

function checkUserAndToken(token,uid){
    return new Promise((resolve, reject) => {
        userRequest.findOne({
            userId: uid
        }, function(err, result) {
            if(result){
                resolve({status:true,data:result})
            }else{
                resolve({status:false})
            }
        });
    });
}

function checkHash(message,hash){
    return new Promise((resolve, reject) => {
        var hmac = crypto.createHmac('sha256', '5f4c9b70-3281-4ee3-bccd-b479eb5011d6');
        var data = hmac.update(message);
        var gen_hmac = data.digest('base64'); 
        // resolve(true);
        if(gen_hmac == hash){
            resolve(true);
        }else{
            resolve(false);
        }
    })
}

function checkTraId(transaction_uuid,request_uuid){
    return new Promise((resolve, reject) => {
        GeneralReqResData.count({
            transactionId: transaction_uuid
        }, function(err, result) {
            //resolve(false);
            if(result == 0){
                resolve(false);
            }else{
                resolve(true);
            }
        })
    })
}

function checkTraIdSettle(transaction_uuid,request_uuid){
    return new Promise((resolve, reject) => {
        GeneralReqResData.count({
            transactionId: transaction_uuid,
            reqName : "credit",
            proccedStatus : {$ne : "failed"}
        }, function(err, result) {
            console.log('result++++++++',result);
            //resolve(false);
            if(result > 1){
                resolve(true);
            }else{
                resolve(false);
            }
        })
    })
}

function checkIdempotentWin(transaction_uuid,round,amount){
    return new Promise((resolve, reject) => {
        GeneralReqResData.count({
            transactionId: transaction_uuid,
            amount : amount,
            round : round
        }, function(err, result) {
            //resolve(false);
            if(result == 0){
                resolve(false);
            }else{
                resolve(true);
            }
        })
    })
}
function checkIdempotentWinGap(transaction_uuid,round,amount){
    return new Promise((resolve, reject) => {
        GeneralReqResData.count({
            transactionId: transaction_uuid,
            amount : amount,
            round : round,
            reqName : "credit",
        }, function(err, result) {
            //resolve(false);
            if(result == 0){
                resolve(false);
            }else{
                resolve(true);
            }
        })
    })
}

function updateRequestFailer(transaction_uuid,settleStatus){            
    return new Promise((resolve, reject) => {        
        ProviderRequest.findOne({
            transactionId: transaction_uuid
        }, function(err, result) {
            if(result){
                result.settleStatus = settleStatus
                result.save();    
            }
            resolve(0);
        });
    });
}

function checkIdempotentRollback(transaction_uuid,round,reference_transaction_uuid){            
    return new Promise((resolve, reject) => {
        
        GeneralReqResData.findOne({
            round : round,
            transactionId : reference_transaction_uuid,
            reqName : "rollback",
        }, function(err, result) {
            //resolve(false);
            if(result){
                resolve(true);
            }else{
                resolve(false);
            }
        })
    })
}

function checkTraIdRollback(transactionId){
    return new Promise((resolve, reject) => {
        GeneralReqResData.count({
            transactionId: transactionId,
            reqName : 'rollback'
        }, function(err, result) {
            //resolve(false);
            if(result == 0){
                resolve(false);
            }else{
                resolve(true);
            }
        })
    });
}

function checkIdempotentBetWin(data){
    return new Promise((resolve, reject) => {
        GeneralReqResData.findOne({
            transactionId: data.transaction_uuid,
            round : data.round,
            amount : data.amount
        }, function(err, result) {
            //resolve(false);
            if(result){
                resolve(true);
            }else{
                resolve(false);
            }
        })
    })
}

// function checkIdempotentRollback(data){
//     return new Promise((resolve, reject) => {
//         GeneralReqResData.findOne({
//             transactionId: data.transaction_uuid,
//             round : data.round,
//             reference_transaction_uuid : data.reference_transaction_uuid
//         }, function(err, result) {
//             //resolve(false);
//             if(result){
//                 resolve(true);
//             }else{
//                 resolve(false);
//             }
//         })
//     })
// }

function checkPrevTran(transactionId){
    return new Promise((resolve, reject) => {
        if(transactionId){
            GeneralReqResData.findOne({
                transactionId: transactionId,
                reqName : 'bet'
            }, function(err, result) {
                if(result){
                    let resObj = {
                        status : true,
                        data : result
                    };
                    resolve(resObj);
                }else{
                    let resObj = {
                        status : false,
                        data : []
                    };
                    resolve(resObj);
                }
            })    
        }else{
            let resObj = {
                status : false,
                data : []
            };
            resolve(resObj);
        }
    });
}

function updatePrevTransaction(transactionId,proceedStatus){
    return new Promise((resolve, reject) => {
        if(transactionId){
            GeneralReqResData.findOne({
                transactionId: transactionId,
                reqName : 'bet'
            }, function(err, result) {
                if(result){
                    result.proceedStatus = proceedStatus;
                    result.save();
                }else{
             
                }
            })  
            resolve(0)
        }
    });
}

function checkDebitTransaction(transactionId){
    return new Promise((resolve, reject) => {
        // GeneralReqResData.findOne({
        //     reference_transaction_uuid: transactionId,
        //     reqName : 'credit'
        // }, function(err, result) {
        //     if(result){
        //         let resObj = {
        //             status : true,
        //             data : result
        //         };
        //         resolve(resObj);
        //     }else{
        //         let resObj = {
        //             status : false,
        //             data : []
        //         };
        //         resolve(resObj);
        //     }
        // })

        ProviderRequest.findOne({
            reference_transaction_uuid: transactionId,
            reqName : 'credit'
        }, function(err, result) {
            if(result){
                let resObj = {
                    status : true,
                    data : result
                };
                resolve(resObj);
            }else{
                let resObj = {
                    status : false,
                    data : []
                };
                resolve(resObj);
            }
        })
    })
}

function checkRollbackTransaction(transactionId){
    return new Promise((resolve, reject) => {
        GeneralReqResData.findOne({
            reference_transaction_uuid: transactionId,
            reqName : 'rollback'
        }, function(err, result) {
            if(result){
                let resObj = {
                    status : true,
                    data : result
                };
                resolve(resObj);
            }else{
                let resObj = {
                    status : false,
                    data : []
                };
                resolve(resObj);
            }
        })
    })
}

function updateTransction(result,req){
    return new Promise((resolve, reject) => {
        var requestArray = {
            method: 'POST',
            // body: bodyData,
            headers: {
                'Content-Type': 'application/json',
            },
            dataType: 'json'
        };
        let data = {
            dreamReq : req,
            pass : "codebrik#123"
        }
        let url = '';
        url =  result.whtLblUrl + "placebet/dream-bet-gap";
        //  url =  "http://localhost:7474/api/v1/placebet/dream-bet-gap";
         //url =  "http://localhost:7271/api/v1/placebet/dream-bet-gap";
        requestify.post(url,data,requestArray)
            .then(function(response) {
                if (response.getCode() == 200) {
                    var response = JSON.parse((response.body));
                    if(response.status == true){
                        let resObj = {   
                            errorCode:0,
                            errorDescription:"Success"
                        }
                        resolve(resObj);
                    }else{
                        let resObj = {   
                            errorCode:3,
                            errorDescription:response.message
                        }
                        resolve(resObj);
                    }
                }else{
                    let resObj = {   
                        errorCode:2,
                        errorDescription:"OP_GENERAL_ERROR"
                    }
                    resolve(resObj);
                }
        }).catch(errr => {
             console.log("whitelabel update error",errr);
            let resObj = {   
                errorCode:1,
                errorDescription:"General"
            }
            resolve(resObj);
        });
    });
}

function updateTransctionRollback(result,req){
    return new Promise((resolve, reject) => {
        var requestArray = {
            method: 'POST',
            // body: bodyData,
            headers: {
                'Content-Type': 'application/json',
            },
            dataType: 'json'
        };
        let data = {
            ezugiReq : req,
            pass : "codebrik#123"
        }
        let url = '';
        url =  result.whtLblUrl + "placebet/rollback-dream-gap";
        //url =  "http://localhost:7474/api/v1/placebet/rollback-dream-gap";
        console.log('url++++++',url);
         //url =  result.whtLblUrl + "/api/v1/placebet/rollback-dream";
        //url =  "http://localhost:2053/api/v1/placebet/rollback-dream";
        requestify.post(url,data,requestArray)
            .then(function(response) {
                if (response.getCode() == 200) {
                    var response = JSON.parse((response.body));
                    if(response.status == true){
                        let resObj = {   
                            errorCode:0,
                            errorDescription:"Success"
                        }
                        resolve(resObj);
                    }else{
                        let resObj = {   
                            errorCode:3,
                            errorDescription:response.message
                        }
                        resolve(resObj);
                    }
                }else{
                    let resObj = {   
                        errorCode:1,
                        errorDescription:"General"
                    }
                    resolve(resObj);
                }
        }).catch(errr => {
            console.log("whitelabel update error");
            let resObj = {   
                errorCode:1,
                errorDescription:"General"
            }
            resolve(resObj);
        });
    });
}


function gameOver(req,url){
    return new Promise((resolve, reject) => {
        var requestArray = {
            method: 'POST',
            // body: bodyData,
            headers: {
                'Content-Type': 'application/json',
            },
            dataType: 'json'
        };
        let data = {
            dreamRes : req,
            pass : "codebrik#123"
        }
        
         //url =  url + "/api/v1/market/dream-settled";
         url =  url + "market/dream-settled-gap";
         //url =   "http://localhost:7204/api/v1/market/dream-settled-gap";
         console.log(url);
         //url =   "http://localhost:2053/api/v1/market/dream-settled";
         requestify.post(url,data,requestArray)
            .then(function(response) {
                if(response.code == 200){
                    let resObj = {   
                        status:true
                    }
                    resolve(resObj);
                }else{
                    let resObj = {   
                        status:false
                    }
                    resolve(resObj);
                }
                
        }).catch(error => {
            let resObj = {   
                status:false
            }
            resolve(resObj);
        })
    });
}

function updateSettleStatus(data){
    Settled.findOne({
        marketId: data.debitTransactionId
    }, function(err, result) {
        if(result){
            result.isSettled = true
            result.save(); 
        }else{
           let obj = {
               marketId : data.debitTransactionId,
               isSettled : true,
               isResettled : false
           } 
           Settled.create(obj);
        }
    });
}

function checkGameId(data,requestType){
    return new Promise((resolve, reject) => {
        if(data.gameId){
            if(data.gameId < 1 || data.gameId > 99){
                let obj = {
                    status : false,
                    message : "Invalid gameId"
                }
                resolve(obj);
            }else{
                let debitBetTypeId = [1,3,4,5,6,7,16,17,18,19,24,27];
                let creditBetTypeId = [101,104,105,106,107,116,117,118,119,124,127];

                if(requestType == "credit"){
                    if(creditBetTypeId.includes(data.betTypeID) == true){
                        let obj = {
                            status : true,
                            message : "Valid Id"
                        }
                        resolve(obj);
                    }else{
                        let obj = {
                            status : false,
                            message : "Invalid betTypeID"
                        }
                        resolve(obj);                                
                    }
                }else{
                    if(debitBetTypeId.includes(data.betTypeID) == true){
                        let obj = {
                            status : true,
                            message : "Valid Id"
                        }
                        resolve(obj);
                    }else{
                        let obj = {
                            status : false,
                            message : "Invalid betTypeID"
                        }
                        resolve(obj);                                
                    }
                }
            }
        }else{
            let obj = {
                status : false,
                message : "Unknown game Id"
            }        
            resolve(obj);
        }
    })
}


function settledUnsettledResult(data){
    return new Promise((resolve, reject) => {
        try{
            data = JSON.parse(data['reqParam']);
            if (data['creditAmount'] < 0) {
                response = {
                    'userId': data['userId'],
                    'status': 'OP_INVALID_AMOUNT'
                }
                let errorObj = {
                    reqUrl: "resettlement",
                    reqTime: new Date(),
                    response: JSON.stringify(response),
                    reqName: 'result',
                    userId: data.userId,
                    transactionId : data.transactionId,
                    roundId : data.roundId,
                    gameId : data.gameId,
                    errorCode : response.status
                }
                ErrorLog.create(errorObj)
                resolve(response);
            }
            else if(data['gameId'] == ""){
                response = {
                    'userId': data['userId'],
                    'status': 'OP_INVALID_PARAMS'
                }
                resolve(response)
            }else{
                let checkGame = gameList.find(game => game['game_id'] == data['gameId']); 
                if(!checkGame){
                    response = {
                        'userId': data['userId'],
                        'status': 'OP_INVALID_GAME'
                    }
                    let errorObj = {
                        reqUrl: "resettlement",
                        reqTime: new Date(),
                        response: JSON.stringify(response),
                        reqName: 'bet',
                        userId: data.userId,
                        transactionId : data.transactionId,
                        roundId : data.roundId,
                        gameId : data.gameId,
                        errorCode : response.status
                    }
                    ErrorLog.create(errorObj)
                    resolve(response)
                }else{
                    data.transactionId = data.transactionId;
                    getUserByUid(data.userId).then(userResult =>  {
                        if(userResult.status == true){
                            data['whtLblUrl'] =  userResult.data.whtLblUrl;
                            checkPrevTran(data.transactionId).then(preTranStatus =>  {
                                preTranStatus.status = true;
                                if(preTranStatus.status == false){
                                    getLatetsBalance(data).then(balance =>  {
                                        let response = {
                                            'userId': data['userId'],
                                            'status': 'OP_TRANSACTION_NOT_FOUND',
                                            'balance':balance.balance
                                        }
                                          
                                        let errorObj = {
                                            reqUrl: "resettlement",
                                            reqTime: new Date(),
                                            response: JSON.stringify(response),
                                            reqName: 'bet',
                                            userId: data.userId,
                                            transactionId : data.transactionId,
                                            roundId : data.roundId,
                                            gameId : data.gameId,
                                            errorCode : response['status']
                                        }
                                        ErrorLog.create(errorObj)
                                        resolve(response);       
                                    })
                                }else{
                                    if(preTranStatus.data.proceedStatus == "rollback"){
                                        data['userId'] = data['userId'];
                                        getLatetsBalance(data).then(balance =>  {
                                            let response = {
                                                'user': data['userId'],
                                                'status': 'OP_ERROR_TRANSACTION_INVALID',
                                                'request_uuid': data['request_uuid'],
                                                'currency' :data['currency'],
                                                'errorCode' : 9,
                                                'timestamp':balance.timestamp,
                                                'balance' : balance.balance
                                            }
                                            updateRequestFailer(data.reference_transaction_uuid,false).then(idemoStatus =>  {
                                            });
                                            resolve(response)       
                                        })
                                    }else{
                                        checkIdempotentWinGap(data.transactionId,data.roundId,data.creditAmount).then(idemoStatus =>  {
                                            idemoStatus = false;
                                            if(idemoStatus == true){
                                                getLatetsBalance(data).then(balance =>  {
                                                    let response = {
                                                        'status': 'OP_DUPLICATE_TRANSACTION',
                                                        'balance':balance.balance
                                                    }
                                                      
                                                    let errorObj = {
                                                        reqUrl: "resettlement",
                                                        reqTime: new Date(),
                                                        response: JSON.stringify(response),
                                                        reqName: 'credit',
                                                        userId: data.userId,
                                                        transactionId : data.transactionId,
                                                        roundId : data.roundId,
                                                        gameId : data.gameId,
                                                        errorCode : response['status']
                                                    }
                                                    ErrorLog.create(errorObj)
                                                    resolve(response);           
                                                })
                                            }else{
                                                let reqAmount = data.creditAmount;
                                                checkTraIdSettle(data.transactionId,data.reqId).then(tranStatus =>  {
                                                    // result = false;
                                                    tranStatus = false;
                                                    if(tranStatus == true){
                                                        getLatetsBalance(data).then(balance =>  {
                                                            let response = {
                                                                'status': 'OP_DUPLICATE_TRANSACTION',
                                                                'balance' : balance.balance
                                                            }
                                                            let errorObj = {
                                                                reqUrl: "resettlement",
                                                                reqTime: new Date(),
                                                                response: JSON.stringify(response),
                                                                reqName: 'credit',
                                                                userId: data.userId,
                                                                transactionId : data.transactionId,
                                                                roundId : data.roundId,
                                                                gameId : data.gameId,
                                                                errorCode : response['status']
                                                            }
                                                            ErrorLog.create(errorObj)
                                                            resolve(response)       
                                                        })
                                                    }else{
                                                        checkDebitTransaction(data.transactionId).then(reqTras =>  {
                                                            if(reqTras.status == true && data.creditAmount == 0){
                                                                    getLatetsBalance(data).then(balance =>  {
                                                                        let response = {
                                                                            'status': 'OP_SUCCESS',
                                                                            'balance' : balance.balance
                                                                        }
                                                                        let errorObj = {
                                                                            reqUrl: "resettlement",
                                                                            reqTime: new Date(),
                                                                            response: JSON.stringify(response),
                                                                            reqName: 'credit',
                                                                            userId: data.userId,
                                                                            transactionId : data.transactionId,
                                                                            roundId : data.roundId,
                                                                            gameId : data.gameId,
                                                                            errorCode : response['status']
                                                                        }
                                                                        ErrorLog.create(errorObj)
                                                                        resolve(response)       
                                                                    })
                                                            }else{
                                                                userRequest.findOne({
                                                                    userId: data.userId
                                                                }, function(err, result) {
                                                                    if(result){
                                                                        data.amount = Number(data.creditAmount) / 100000;
                                                                        data.proccedStatus = preTranStatus.data.proceedStatus;
                                                                        gameOver(data,result.whtLblUrl).then(gameRes =>{
                                                                            // console.log("gameRes+++++++++++++",gameRes);
                                                                            if(gameRes.status == true){
                                                                                    getLatetsBalance(data).then(balance =>  {
                                                                                        // console.log("balance+++++++++++++",balance);
                                                                                        let resp = {
                                                                                            'status': 'OP_SUCCESS',
                                                                                            'balance': balance.balance,
                                                                                        }

                                                                                        let errorObj = {
                                                                                            reqUrl: "resettlement",
                                                                                            reqTime: new Date(),
                                                                                            response: JSON.stringify(resp),
                                                                                            reqName: 'credit',
                                                                                            userId: data.userId,
                                                                                            transactionId : data.transactionId,
                                                                                            roundId : data.roundId,
                                                                                            gameId : data.gameId,
                                                                                            errorCode :resp['status']
                                                                                        }
                                                                                        ErrorLog.create(errorObj)
                                                                                        // console.log("resp++++++++++++",resp);     
                                                                                        updateRequestFailer(data.transactionId,true).then(idemoStatus =>  {
                                                                                        });
                                                                                        //update previous transaction
                                                                                        updatePrevTransaction(data.transactionId,'settled').then(updateStatus =>  {
                                                                                            // console.log("updateStatus");
                                                                                        });
        
                                                                                        resolve(resp);
                                                                                        
                                                                                    })                                           
                                                                            }else{
        
                                                                                let resp = {
                                                                                    'userId': data['userId'],
                                                                                    'status': 'OP_GENERAL_ERROR',
                                                                                }
                                                                                let errorObj = {
                                                                                    reqUrl: "resettlement",
                                                                                    reqTime: new Date(),
                                                                                    response: JSON.stringify(resp),
                                                                                    reqName: 'credit',
                                                                                    userId: data.userId,
                                                                                    transactionId : data.transactionId,
                                                                                    roundId : data.roundId,
                                                                                    gameId : data.gameId,
                                                                                    errorCode :resp['status']
                                                                                }
                                                                                ErrorLog.create(errorObj)
                                                                                updateRequestFailer(data.transactionId,false).then(idemoStatus =>  {
                                                                                });
                                                                                resolve(resp)
                                                                            }
                                                                        });
                                                                    }else{
                                                                        let resp = {
                                                                            'status': 'OP_USER_NOT_FOUND',
                                                                            'balance': 0,
                                                                        }

                                                                        let errorObj = {
                                                                                            reqUrl: "resettlement",
                                                                                            reqTime: new Date(),
                                                                                            response: JSON.stringify(resp),
                                                                                            reqName: 'credit',
                                                                                            userId: data.userId,
                                                                                            transactionId : data.transactionId,
                                                                                            roundId : data.roundId,
                                                                                            gameId : data.gameId,
                                                                                            errorCode :resp['status']
                                                                                        }
                                                                                        ErrorLog.create(errorObj) 
                                                                        updateRequestFailer(data.transactionId,false).then(idemoStatus =>  {
                                                                        });
                                                                       
                                                                        resolve(resp)
                                                                    }
                                                                });
                                                            }
                                                        });
                                                    }
                                                })        
                                            }
                                        });
        
                                    }
                                }
                            });
                        }else{
                            let response = {
                                'userId': data['userId'],
                                'status': 'OP_USER_BLOCKED',
                            }
                            let errorObj = {
                                reqUrl: "resettlement",
                                reqTime: new Date(),
                                response: JSON.stringify(response),
                                reqName: 'bet',
                                userId: data.userId,
                                transactionId : data.transactionId,
                                roundId : data.roundId,
                                gameId : data.gameId,
                                errorCode : response.status
                            }
                            ErrorLog.create(errorObj)
                            resolve(response);
                        }
                    });
                }
            }

        }catch (err) {
             console.log("error+++++++++++",err);
            // let response = {
            //     'user': data['user_id'],
            //     'status': 'RS_ERROR_UNKNOWN',
            //     'request_uuid': payload['request_uuid']
            // }
            // return res.json(response)
        }
    })
}

function rollbackUnsettledResult(data){
    return new Promise((resolve, reject) => {
        data = JSON.parse(data['reqParam']);
        let payload = data;
        try{
            getUserByUid(data.userId).then(result =>  {
                if(result.status == true){
                    payload['whtLblUrl'] =  result.data.whtLblUrl;
                    checkPrevTran(data.transactionId).then(idempotentStatus =>  {
                        if(idempotentStatus.status == false){
                            getLatetsBalance(result.data).then(balance =>  {
                                let response = {
                                    'userId': payload['userId'],
                                    'status': 'OP_TRANSACTION_NOT_FOUND',
                                    'balance':balance.balance
                                }
                                  
                                let errorObj = {
                                    reqUrl: "rerollback",
                                    reqTime: new Date(),
                                    response: JSON.stringify(response),
                                    reqName: 'rollback',
                                    userId: data.userId,
                                    transactionId : data.transactionId,
                                    roundId : data.roundId,
                                    gameId : data.gameId,
                                    errorCode : response.status
                                }
                                ErrorLog.create(errorObj)
                                resolve(response); 
                            })
            
                        }else{
                            checkIdempotentRollback(data.transactionId,data.roundId,data.transactionId).then(idemoStatus =>  {
                                idemoStatus = false;
                                if(idemoStatus == true){
                                    getLatetsBalance(result.data).then(balance =>  {
                                        let response = {
                                            'userId': payload['userId'],
                                            'status': 'OP_DUPLICATE_TRANSACTION',
                                            'balance':balance.balance
                                        }
                                          
                                        let errorObj = {
                                            reqUrl: "rerollback",
                                            reqTime: new Date(),
                                            response: JSON.stringify(response),
                                            reqName: 'rollback',
                                            userId: data.userId,
                                            transactionId : data.transactionId,
                                            roundId : data.roundId,
                                            gameId : data.gameId,
                                            errorCode : response.status
                                        }
                                        ErrorLog.create(errorObj)
                                        resolve(response); 
                                    })
                                }else{
                                    updateTransctionRollback(result.data,data).then(transData =>{
                                        if(transData.errorCode == 0){
                                            getLatetsBalance(result.data).then(balance =>  {
                                                // console.log("balance++++++++++",balance);
                                                let response = {
                                                    'user': payload['userId'],
                                                    'errorCode' : 0,
                                                    'timestamp':balance.timestamp,
                                                    'token':payload['token'],
                                                    'status': 'OP_SUCCESS',
                                                    'balance' : balance.balance,
                                                    'request_uuid': payload['reqId'],
                                                    'round' : payload['roundId'],
                                                    'transactionId':payload['transactionId']
                                                }
                                                let errorObj = {
                                                    reqUrl: "rerollback",
                                                    reqTime: new Date(),
                                                    response: JSON.stringify(response),
                                                    reqName: 'rollback',
                                                    userId: data.userId,
                                                    transactionId : data.transactionId,
                                                    roundId : data.roundId,
                                                    gameId : data.gameId,
                                                    errorCode :response['status']
                                                }
                                                ErrorLog.create(errorObj) 
                                                let resObj = {
                                                    status : "OP_SUCCESS",
                                                    balance: balance.balance
                                                }
                                                resolve(resObj)      
                                            })
                                        }else{
                                            if(transData.errorCode == 3){
                                                let response = {
                                                    'status': transData['errorDescription']
                                                }
                                                updateRequestFailer(data.transactionId,false).then(idemoStatus =>  {
                                                });
                                                let errorObj = {
                                                    reqUrl: "rerollback",
                                                    reqTime: new Date(),
                                                    response: JSON.stringify(response),
                                                    reqName: 'rollback',
                                                    userId: data.userId,
                                                    transactionId : data.transactionId,
                                                    roundId : data.roundId,
                                                    gameId : data.gameId,
                                                    errorCode :response['status']
                                                }
                                                ErrorLog.create(errorObj) 
                                                resolve(response);   
                                            }else{
                                                let response = {
                                                    'status': 'OP_GENERAL_ERROR'
                                                }
                                                updateRequestFailer(data.transactionId,false).then(idemoStatus =>  {
                                                });
                                                let errorObj = {
                                                    reqUrl: "rerollback",
                                                    reqTime: new Date(),
                                                    response: JSON.stringify(response),
                                                    reqName: 'rollback',
                                                    userId: data.userId,
                                                    transactionId : data.transactionId,
                                                    roundId : data.roundId,
                                                    gameId : data.gameId,
                                                    errorCode :response['status']
                                                }
                                                ErrorLog.create(errorObj) 
                                                resolve(response);   
                                            }
                                        }
                                    })   
                                 }
                            });
                        }
                    });
                    
                    
                }else{
                    let response = {
                        'status': 'OP_USER_NOT_FOUND',
                    }
                    let errorObj = {
                        reqUrl: "rerollback",
                        reqTime: new Date(),
                        response: JSON.stringify(response),
                        reqName: 'rollback',
                        userId: data.userId,
                        transactionId : data.transactionId,
                        roundId : data.roundId,
                        gameId : data.gameId,
                        errorCode :response['status']
                    }
                    ErrorLog.create(errorObj) 
                    resolve(response);   
                }
            });
        }catch(err){

        }
    })
}
