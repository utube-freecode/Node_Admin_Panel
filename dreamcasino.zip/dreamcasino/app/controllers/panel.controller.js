let User = require('../models/user.model');
let Helper = require('../helpers/common.helper');
let userRequest = require('../models/userRequest.model');
let GeneralReqResData = require('../models/generalReqResLogs.model');
let Settled = require('../models/settled.model');
let Settledevent = require('../models/settledevent.model');
let whitelabel = require('../models/whitelabel.model');
let Reaction = require('../models/reaction.model');
var requestify = require('requestify');
const fs = require("fs");
const path = require("path");
let async = require('async');
var crypto = require('crypto');
let constants = require(`../../config/constants`);
let gameList = require(`../../config/gameListLive.json`);
const { networkInterfaces } = require('os');
const axios = require('axios');
var redis = require('redis');
let Constants = require(`../../config/constants`);
let gameListJson = require(`../services/gameListLive.json`);
let partnerId = constants.partnerId;
 let private_keyPath = path.resolve("/home/smdcnew/dreamcasino/app/services/PrivateKeyLive.txt");
 let public_keyPath =  path.resolve("/home/smdcnew/dreamcasino/app/services/PublicKeyLive.txt");
//   let private_keyPath = path.resolve("/media/roy/6e4fd71d-0ad4-4641-b2f8-2f3644c64595/var/www/html/projects/dreamcasino/app/services/PrivateKeyLive.txt");
//   let public_keyPath =  path.resolve("/media/roy/6e4fd71d-0ad4-4641-b2f8-2f3644c64595/var/www/html/projects/dreamcasino/app/services/PublicKeyLive.txt");

var Redisclient = redis.createClient(
    Constants.redisServer.dbPort,
    Constants.redisServer.dbHost,
    Constants.redisServer.dbOptions
);
const jwt = require("jsonwebtoken");
let secretKey = process.env.JWT_SECRET;
let _ = require('lodash');
let ProviderRequest = require('../models/providerRequest.model');
let ErrorLog = require('../models/errorlog.model');
const json2xls = require('json2xls');
const { options } = require('../routes/panel.routes');
const generalReqResLogsModel = require('../models/generalReqResLogs.model');
const moment = require("moment");
const momenttz = require('moment-timezone');
const activeGameModels = require('../models/activeGame.models');

module.exports = {

    welcome: (req, res, next) => {
        res.status(200).send({
            "status": true,
            "message": "welcome",
        })
    },

    getUserRequestList : async(req, res, next) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data.searchStr, "searchStr")
            console.log(data.dropdownStr, "dropdownStr")

            const page = data.page; // Page number
            console.log(page, "page")
            const limit = 50; // Documents per page
            const skip = (page - 1) * limit;

            // const totalItems = await userRequest.countDocuments();
            // const totalPages = Math.ceil(totalItems / limit);

            const matchStage = {};

            // Multi Selected Options
            if (data.dropdownStr && data.dropdownStr.length > 0) {
                matchStage.whtLblUrl = { 
                    $in: data.dropdownStr.map(value => new RegExp(value, "i")) 
                };
            }

            // Generic $or condition to search across all fields
            if (data.searchStr) {
                const searchFields = ["userName", "userId", "token"]; // Add all fields
                matchStage.$or = searchFields.map(field => ({
                    [field]: { $regex: data.searchStr, $options: "i" }
                }));
            }

            // Remove $or if no conditions are added (in case searchFields is empty)
            if (matchStage.$or && matchStage.$or.length === 0) {
                delete matchStage.$or;
            }

            console.log(matchStage, "matchStage")

            const whtLblUrlData = await userRequest.aggregate([
                {
                    $group: {
                        _id: "$whtLblUrl",             
                        whtLblUrlCount: { $sum: 1 }  
                      }
                },
                {
                    $sort: { _id: 1 } // Sort alphabetically by _id (which is whtLblUrl)
                }
            ])

            if(!whtLblUrlData){
                return res.json(404).json({
                    message : "URL data NOT found"
                })
            }

            const pipeline = [];


            if(data.searchStr || data.dropdownStr){
                pipeline.push(
                    {
                        $match: matchStage
                    },
                    {
                        $facet: {
                            metadata: [
                                { $count: "total" }
                            ],
                            data: [
                                {
                                    $sort: { createdAt: -1 },
                                  },
                                { $skip: skip },
                                { $limit: limit },
                                {
                                    $project: {
                                        userName: 1,
                                        userId: 1,
                                        token: 1,
                                        currency: 1,
                                        whtLblUrl: 1,
                                        balance: 1,
                                        createdAt : 1,
                                        updatedAt : 1
                                    }
                                }
                            ]
                        }
                    }
                );    
            }
            else{
                pipeline.push(
                    {
                        $facet: {
                            metadata: [
                                { $count: "total" }
                            ],
                            data: [
                                {
                                    $sort: { createdAt: -1 }, 
                                  },
                                { $skip: skip },
                                { $limit: limit },
                                {
                                    $project: {
                                        userName: 1,
                                        userId: 1,
                                        token: 1,
                                        currency: 1,
                                        whtLblUrl: 1,
                                        balance: 1,
                                        createdAt : 1,
                                        updatedAt : 1
                                    }
                                }
                            ]
                        }
                    }
                );    
            }        
            
            const users = await userRequest.aggregate(pipeline)

            //console.log(users, "users")

            if(!users){
                return res.status(404).json({
                    message : "User requests not found"
                })
            }

            return res.status(200).json({
                message : "User requests fetched successfully",
                data : users,
                whtLblUrlData : whtLblUrlData,
                page : page,
                limit : limit
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },


    getGeneralLogs : async(req, res, next) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.searchFields, "searchFields")
            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")
            console.log(data?.data?.filters, "filters")

            console.log(data?.data?.reqType, "dropdownReq")


            const page = data.page; // Page number
            console.log(page, "page")
            const limit = data.pageSize; // Documents per page
            const skip = (page - 1) * limit;

            // const totalItems = await userRequest.countDocuments();
            // const totalPages = Math.ceil(totalItems / limit);

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (data?.data?.fromDate && data?.data?.toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(data?.data?.fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(data?.data?.toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            data?.data?.filters.forEach((filter) => {
                if (data?.data?.searchFields[filter]) {
                    if (filter === 'User Name') {
                        matchStage.userName = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'User ID') {
                        matchStage.userId = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Amount') {
                        matchStage.amount = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Round') {
                        matchStage.round = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Transaction ID') {
                        matchStage.transactionId = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Category') {
                        matchStage.category = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                }
            });

            if (data?.data?.reqType) {
                if(data?.data?.reqType === "Bet Request"){
                    matchStage.reqUrl = { $regex: 'bet', $options: "i" };
                }
                else if(data?.data?.reqType === "Result Request"){
                    matchStage.reqUrl = { $regex: 'result', $options: "i" };
                }
            }

            // Generic $or condition to search across all fields
            // if (data.searchId) {
            //     const searchFields = ["userId", "round", "amount", "transactionId"]; // Add all fields
            //     matchStage.$or = searchFields.map(field => ({
            //         [field]: { $regex: data.searchId, $options: "i" }
            //     }));
            // }

            // Remove $or if no conditions are added (in case searchFields is empty)
            // if (matchStage.$or && matchStage.$or.length === 0) {
            //     delete matchStage.$or;
            // }

            console.log(matchStage, "matchStage")  

            const pipeline = [];

            pipeline.push(
                {
                    $match: matchStage
                },
                {
                    $facet: {
                        metadata: [
                            { $count: "total" }
                        ],
                        data: [
                            {
                                $sort: { createdAt: -1 },
                            },
                            { $skip: skip },
                            { $limit: limit },
                            {
                                $project: {
                                    reqUrl: 1,
                                    userId: 1,
                                    reqTime: 1,
                                    round: 1,
                                    amount: 1,
                                    transactionId: 1,
                                    reqParam : 1,
                                    category : 1,
                                    game_id : 1,
                                    game_name : 1,
                                    provider_name : 1,
                                    sub_provider_name : 1,
                                    userName : 1
                                }
                            }
                        ]
                    }
                }
            );   

            
            const logs = await generalReqResLogsModel.aggregate(pipeline)

            //console.log(logs, "logs")

            if(!logs){
                return res.status(404).json({
                    message : "Logs not found"
                })
            }

            return res.status(200).json({
                message : "Logs fetched successfully",
                data : logs,
                page : page,
                limit : limit
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },


    getGeneralLogById : async(req, res, next) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data._id, "_id")

            if(!data._id){
                return res.status(400).json({
                    message : "id is required"
                })
            }

            const logData = await generalReqResLogsModel.findById(data?._id)

            //console.log(logData, "logData")

            if(!logData){
                return res.status(404).json({
                    message : "Log data not found"
                })
            }

            return res.status(200).json({
                message : "Log data fetched successfully",
                data : logData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    getGeneralLogAnalysis : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.userId, "userId")
            console.log(data?.selectedDate, "selectedDate")

            if(!data.userId && !data.selectedDate){
                return res.status(400).json({
                    message : "User id and date is required"
                })
            }

            const user = await generalReqResLogsModel.findOne({userId : data?.userId})

            if(!user){
                return res.status(404).json({
                    message : "User id not found"
                })
            }

            //const date = "2025-01-24";

            // Calculate start and end of the day
            const startOfDay = momenttz.tz(data?.selectedDate, "Asia/Kolkata").startOf("day").toDate();
            const endOfDay = momenttz.tz(data?.selectedDate, "Asia/Kolkata").endOf("day").toDate();

            console.log(startOfDay, "startOfDay")
            console.log(endOfDay, "endOfDay")

            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match: {
                    userId : data?.userId,
                    createdAt: {
                      $gte: startOfDay,
                      $lt: endOfDay
                    },
                    amount: { $exists: true, $ne: "" } // Ensure the field exists and is not empty
                  }
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: null,
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                }
              ]);
              
              

            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Analysis data not found"
                })
            }

            const proceedStatusData = await generalReqResLogsModel.aggregate([
                {
                  $match: {
                    userId : data?.userId,
                    createdAt: {
                      $gte: startOfDay,
                      $lt: endOfDay
                    },
                    amount: { $exists: true, $ne: "" } // Ensure the field exists and is not empty
                  }
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: '$proceedStatus',
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                }
              ]);

              //console.log(proceedStatusData, "proceedStatusData")

            if(!proceedStatusData){
                return res.status(404).json({
                    message : "Analysis data not found"
                })
            }

            return res.status(200).json({
                message : "Analysis data fetched successfully",
                data : [sumData, proceedStatusData],
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    getGeneralLogVisualAnalysis : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.userId, "userId")
            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const userId = data?.data?.userId
            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!userId && !fromDate && !toDate){
                return res.status(400).json({
                    message : "User id and date is required"
                })
            }

            const user = await generalReqResLogsModel.findOne({userId : userId})

            if(!user){
                return res.status(404).json({
                    message : "User id not found"
                })
            }

            const matchStage = {};
            matchStage.userId = userId

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/betrequest', $options: "i" }

            console.log(matchStage, "matchStage")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                $group: {
                    _id: "$transactionId",
                        provider_name : {$first : "$provider_name"},
                        sub_provider_name : {$first : "$sub_provider_name"},
                        game_name : {$first : "$game_name"},
                        uniqueAmount : {$first : "$numericAmount"},
                        userId: {$first : "$userId"},
                        userName: {$first: "$userName"},
                    }
                },
                {
                  $group: {
                    _id: {
                        provider_name: "$provider_name",
                        sub_provider_name: "$sub_provider_name",
                        game_name: "$game_name",
                        userId: "$userId",
                         userName: "$userName"
                    },
                    totalAmount: { $sum: "$uniqueAmount" } // Sum the converted numeric amount
                  }
                }
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Visual Analysis data not found"
                })
            }

            return res.status(200).json({
                message : "Visual Analysis data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },


    getGeneralLogVisualAnalysisAmount : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.userId, "userId")
            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const userId = data?.data?.userId
            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!userId && !fromDate && !toDate){
                return res.status(400).json({
                    message : "User id and date is required"
                })
            }

            const user = await generalReqResLogsModel.findOne({
                $or: [
                  { userId: userId },
                  { userName: { $regex: userId, $options: "i" } }
                ]
              })

            if(!user){
                return res.status(404).json({
                    message : "User not found"
                })
            }

            const matchStage = {};
            //matchStage.userId = userId

            // Generic $or condition to search across all fields
            if (userId) {
                const searchFields = ["userName", "userId"]; // Add all fields
                matchStage.$or = searchFields.map(field => ({
                    [field]: { $regex: userId, $options: "i" }
                }));
            }

            // Remove $or if no conditions are added (in case searchFields is empty)
            if (matchStage.$or && matchStage.$or.length === 0) {
                delete matchStage.$or;
            }


            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty

            console.log(matchStage, "matchStage")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: {
                        provider_name: "$provider_name",
                        sub_provider_name: "$sub_provider_name",
                        game_name: "$game_name",
                        userId: "$userId",
                        userName: "$userName",
                        reqUrl : "$reqUrl",
                    },
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
                {
                    $group : {
                        _id: {
                            provider_name: "$_id.provider_name",
                            sub_provider_name:
                              "$_id.sub_provider_name",
                            game_name: "$_id.game_name",
                            userId: "$_id.userId",
                            userName: "$_id.userName",
                          },
                          reqUrls: {
                            $push: {
                              reqUrl: "$_id.reqUrl",
                              amount: "$totalAmount"
                            }
                          }
                    }
                }
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Visual Analysis Amount data not found"
                })
            }

            return res.status(200).json({
                message : "Visual Analysis data Amount fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    getAnalysisByGames : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/betrequest', $options: "i" }
            console.log(matchStage, "matchStage")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: {
                        provider_name: "$provider_name",
                        sub_provider_name: "$sub_provider_name",
                        game_name: "$game_name",
                    },
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
                {
                    $group : {
                        _id: {
                            provider_name: "$_id.provider_name",
                            sub_provider_name: "$_id.sub_provider_name",
                          },
                          gameNames: {
                            $push: {
                              game_name: "$_id.game_name",
                              amount: "$totalAmount"
                            }
                          }
                    }
                },
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Analysis by games data not found"
                })
            }

            return res.status(200).json({
                message : "Analysis by games data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },


    getAnalysisByProviders : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/betrequest', $options: "i" }
            console.log(matchStage, "matchStageProviders")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: {
                        provider_name: "$provider_name",
                        sub_provider_name: "$sub_provider_name",
                    },
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Analysis data not found"
                })
            }

            return res.status(200).json({
                message : "Analysis data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    getAnalysisTotal : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/betrequest', $options: "i" }
            console.log(matchStage, "matchStage")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: null,
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Analysis data not found"
                })
            }

            return res.status(200).json({
                message : "Analysis data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    getWinAnalysisByGames : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/resultrequest', $options: "i" }
            console.log(matchStage, "matchStage")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: {
                        provider_name: "$provider_name",
                        sub_provider_name: "$sub_provider_name",
                        game_name: "$game_name",
                    },
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
                {
                    $group : {
                        _id: {
                            provider_name: "$_id.provider_name",
                            sub_provider_name: "$_id.sub_provider_name",
                          },
                          gameNames: {
                            $push: {
                              game_name: "$_id.game_name",
                              amount: "$totalAmount"
                            }
                          }
                    }
                },
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "WIn Analysis by games data not found"
                })
            }

            return res.status(200).json({
                message : "Win Analysis by games data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },


    getWinAnalysisByProviders : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/resultrequest', $options: "i" }
            console.log(matchStage, "matchStageProviders")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: {
                        provider_name: "$provider_name",
                        sub_provider_name: "$sub_provider_name",
                    },
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Win Analysis data not found"
                })
            }

            return res.status(200).json({
                message : "Win Analysis data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    getWinAnalysisByGamesUser : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/resultrequest', $options: "i" }
            console.log(matchStage, "matchStage")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: {
                        // provider_name: "$provider_name",
                        // sub_provider_name: "$sub_provider_name",
                        game_name: "$game_name",
                        userId: "$userId",
                        userName: "$userName",
                    },
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
                {
                    $group : {
                        _id: {
                            // provider_name: "$_id.provider_name",
                            // sub_provider_name: "$_id.sub_provider_name",
                            userId: "$_id.userId",
                            userName: "$_id.userName",
                          },
                          gameNames: {
                            $push: {
                              game_name: "$_id.game_name",
                              amount: "$totalAmount"
                            }
                          }
                    }
                },
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "WIn Analysis by games data not found"
                })
            }

            return res.status(200).json({
                message : "Win Analysis by games data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },


    getWinAnalysisByProvidersUser : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/resultrequest', $options: "i" }
            console.log(matchStage, "matchStageProviders")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: {
                        provider_name: "$provider_name",
                        sub_provider_name: "$sub_provider_name",
                        userId: "$userId",
                        userName: "$userName",
                    },
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Win Analysis data not found"
                })
            }

            return res.status(200).json({
                message : "Win Analysis data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    getWinAnalysisByGamesUserArray : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/resultrequest', $options: "i" }
            console.log(matchStage, "matchStage")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                  $addFields: {
                    numericAmount: { $toDouble: "$amount" } // Convert the string to a number
                  }
                },
                {
                  $group: {
                    _id: {
                        provider_name: "$provider_name",
                        sub_provider_name: "$sub_provider_name",
                        game_name: "$game_name",
                        userId: "$userId",
                        userName: "$userName",
                    },
                    totalAmount: { $sum: "$numericAmount" } // Sum the converted numeric amount
                  }
                },
                {
                    $group : {
                        _id: {
                            provider_name: "$_id.provider_name",
                            sub_provider_name: "$_id.sub_provider_name",
                          },
                          gameNames: {
                            $push: {
                              game_name: "$_id.game_name",
                              amount: "$totalAmount",
                              userId: "$_id.userId",
                              userName: "$_id.userName", 
                            }
                          }
                    }
                },
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "WIn Analysis by games data not found"
                })
            }

            return res.status(200).json({
                message : "Win Analysis by games data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },


    getAnalysisCount : async(req, res) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.fromDate, "fromDate")
            console.log(data?.data?.toDate, "toDate")

            const fromDate = data?.data?.fromDate
            const toDate = data?.data?.toDate
            const filters = data?.data?.filters
            const searchFields = data?.data?.searchFields


            if(!fromDate && !toDate){
                return res.status(400).json({
                    message : "Date is required"
                })
            }

            const matchStage = {};

            // Add conditions based on fromDate and toDate
            if (fromDate && toDate) {
                // Calculate start and end of the day
                const startOfDay = momenttz.tz(fromDate, "Asia/Kolkata").startOf("day").toDate();
                const endOfDay = momenttz.tz(toDate, "Asia/Kolkata").endOf("day").toDate();

                console.log(startOfDay, "startOfDay")
                console.log(endOfDay, "endOfDay")

                matchStage.createdAt = {
                    $gte: startOfDay, // greater than or equal to fromDate
                    $lte: endOfDay, // less than or equal to toDate
                };
            }

            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            filters.forEach((filter) => {
                if (searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: searchFields[filter], $options: "i" }
                    }
                }
            });

            //matchStage.amount = { $exists: true, $ne: "" } // Ensure the field exists and is not empty
            matchStage.reqUrl = { $regex: '/betrequest', $options: "i" }
            console.log(matchStage, "matchStageCount")  


            const sumData = await generalReqResLogsModel.aggregate([
                {
                  $match : matchStage
                },
                {
                    $count : "documentsCount"
                }
              ]);
              
              
            //console.log(sumData, "sumData")

            if(!sumData){
                return res.status(404).json({
                    message : "Analysis data not found"
                })
            }

            return res.status(200).json({
                message : "Analysis data fetched successfully",
                data : sumData,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    insertGames : async(req, res, next) => {
        try {

            // Read JSON file
            const data = JSON.parse(fs.readFileSync("/home/admin1/Documents/dreamcasino/config/gameListLive.json", "utf-8"));

            let games = null;

            // Insert into MongoDB
            if (Array.isArray(data)) {
                games = await activeGameModels.insertMany(data);
            } else {
                return res.status(404).json({
                    message : "games not found"
                })
            }

            if(!games){
                return res.status(404).json({
                    message : "games failed to insert"
                })
            }

            return res.status(200).json({
                message : "Games inserted successfully",
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    getActiveGames : async(req, res, next) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?.data?.searchFields, "searchFields")
            console.log(data?.data?.filters, "filters")
            console.log(data?.data?.statusFilter, "statusFilter")


            //const page = 1; // Page number
            const page = data.page; // Page number
            console.log(page, "page")
            //const limit = 50; // Documents per page
            const limit = data.pageSize; // Documents per page
            const skip = (page - 1) * limit;

            // const totalItems = await userRequest.countDocuments();
            // const totalPages = Math.ceil(totalItems / limit);

            const matchStage = {};

            if(data?.data?.statusFilter){
                matchStage.status = { $regex: data?.data?.statusFilter, $options: "i" }
            }


            // Add conditions based on filters (e.g., "User ID", "Amount", etc.)
            data?.data?.filters.forEach((filter) => {
                if (data?.data?.searchFields[filter]) {
                    if (filter === 'Category') {
                        matchStage.category = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Provider') {
                        matchStage.provider_name = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Supplier') {
                        matchStage.sub_provider_name = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game Name') {
                        matchStage.game_name = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                    if (filter === 'Game ID') {
                        matchStage.game_id = { $regex: data?.data?.searchFields[filter], $options: "i" }
                    }
                }
            });

            console.log(matchStage, "matchStage")  

            const pipeline = [];

            pipeline.push(
                {
                    $match: matchStage
                },
                {
                    $facet: {
                        metadata: [
                            { $count: "total" }
                        ],
                        data: [
                            {
                                $sort: { game_id: 1 },
                            },
                            { $skip: skip },
                            { $limit: limit },
                        ]
                    }
                }
            );   

            
            const games = await activeGameModels.aggregate(pipeline)

            //console.log(logs, "logs")

            if(!games){
                return res.status(404).json({
                    message : "games not found"
                })
            }

            return res.status(200).json({
                message : "Games fetched successfully",
                data : games,
                page : page,
                limit : limit
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

    modifyGameStatusById : async(req, res, next) => {
        try {

            const data = req.body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body;
            console.log(data, "data") 

            console.log(data?._id, "_id")
            console.log(data?.status, "updateToStatus")
            

            if(!data?._id){
                return res.status(400).json({
                    message : "id is required"
                })
            }

            const gameData = await activeGameModels.updateOne(
                { _id: data?._id },
                { $set: { status: data?.status } }
              );

            console.log(gameData, "gameData")

            if(!gameData){
                return res.status(404).json({
                    message : "game status not updated"
                })
            }

            return res.status(200).json({
                message : `Game status updated successfully to ${data?.status}`,
            })

        } catch (error) {
            console.log(error)
            res.status(500).json({
                message : "Something went wrong"
            })
        }
    },

}; 

