'use strict';
let mongoose = require('bluebird').promisifyAll(require('mongoose'));
let Schema = mongoose.Schema;
let autopopulate = require('mongoose-autopopulate');
let paginate = require('mongoose-paginate');

let Reaction = new Schema({
    action_name: {
        type: String,
    },
    wlb_name: {
        type: String
    },
    gameName : {
        type: String
    },
    gameId : {
        type: Number
    },
    hookurl : {
        type: String
    },
    body : [],
    data : [],
    isDeleted: {
        type: Boolean,
        default: false
    },
    isActive: {
        type: Boolean,
        default: true
    },
}, {timestamps: true});


Reaction.plugin(autopopulate);
Reaction.plugin(paginate);

module.exports = mongoose.model('Reaction', Reaction);