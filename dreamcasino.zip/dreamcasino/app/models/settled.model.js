'use strict';

let mongoose = require('bluebird').promisifyAll(require('mongoose'));
let Schema = mongoose.Schema;
let autopopulate = require('mongoose-autopopulate');
let paginate = require('mongoose-paginate');

let Settled = new Schema({
    marketId: {
        type: String,
        required: true,
    },
    isSettled: {
        type: Boolean,
        default: true,
    },
    isResettled: {
        type: Boolean,
        default: false,
    },

}, { timestamps: true });

Settled.plugin(autopopulate);
Settled.plugin(paginate);

module.exports = mongoose.model('Settled', Settled);