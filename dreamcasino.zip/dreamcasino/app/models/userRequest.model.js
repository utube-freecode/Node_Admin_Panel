'use strict';

let mongoose = require('bluebird').promisifyAll(require('mongoose'));
let Schema = mongoose.Schema;
let autopopulate = require('mongoose-autopopulate');
let paginate = require('mongoose-paginate');

let userRequest = new Schema({
    userId: {
        type: String,
        required: true,
        unique: true,
    },
    userName: {
        type: String,
        required: true,
    },
    balance: {
        type: Number,
        default: 0,
    },
    currency:{
        type: String,
        default: 'INR',        
    },
    token : {
        type: String
    },
    playersTokenAtLaunch : {
        type: String
    },
    whtLblUrl : {
        type: String
    },
    casinoType : {
        type: String
    },
    isDeleted: {
        type: Boolean,
        default: false,
    },


}, { timestamps: true });

userRequest.plugin(autopopulate);
userRequest.plugin(paginate);

// remove password and __v filed when its populate.

userRequest.methods.toJSON = function() {
    var obj = this.toObject();
    delete obj.__v;
    return obj;
}

module.exports = mongoose.model('userRequest', userRequest);