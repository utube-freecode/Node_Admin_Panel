'use strict';

let mongoose = require('bluebird').promisifyAll(require('mongoose'));
let Schema = mongoose.Schema;
let autopopulate = require('mongoose-autopopulate');
let paginate = require('mongoose-paginate');

let Setting = new Schema({
    server_on: {
        type: Boolean,
        required: true,
        default: false
    },
    kite_server_on: {
        type: Boolean,
        required: true,
        default: false
    },
    dotnet_server_on: {
        type: Boolean,
        required: true,
        default: false
    },
    isActive: {
        type: Boolean,
        default: true
    },
    isDeleted: {
        type: Boolean,
        default: false
    }
}, { timestamps: true });

Setting.plugin(autopopulate);
Setting.plugin(paginate);

module.exports = mongoose.model('Setting', Setting);