'use strict';

let mongoose = require('bluebird').promisifyAll(require('mongoose'));
let Schema = mongoose.Schema;
let autopopulate = require('mongoose-autopopulate');
let paginate = require('mongoose-paginate');

let ProviderRequest = new Schema({
  reqUrl: {
    type: String
  },
  request_uuid : {
    type: String    
  },
  transactionId: {
    type: String
  },
    reqName: {
    type: String
  },
  reqParam: {
    type: String
  },
    userId: {
    type: String
  },
  debitTransactionId: {
    type: String
  },
  reqMethod: {
    type: String
  },
  response: {
    type: String
  },
  errorCode : {
    type: String    
  },
    reqTime: {
    type: Date
  },
    resTime: {
    type: Date
  },
  roundId : {
    type: String
  },
  gameId :  {
    type: String
  },
  amount : {
    type: String
  },
}, {timestamps: true});

ProviderRequest.plugin(autopopulate);
ProviderRequest.plugin(paginate);

module.exports = mongoose.model('ProviderRequest', ProviderRequest);