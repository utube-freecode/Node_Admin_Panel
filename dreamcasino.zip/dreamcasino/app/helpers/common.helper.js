'use strict';

let config = require(`../../config/${process.env.NODE_ENV}.js`);
let alphanumeric = require('alphanumeric-id');
let aes256 = require('aes256');
let constants = require(`../../config/constants.js`);
const redis = require("redis");
var _ = require('underscore');

let Sentry = require("@sentry/node");
let Tracing = require("@sentry/tracing");

module.exports = {



    consolelog: (req, pattern = 'null') => {

        if (process.env.NODE_ENV == 'development') {

            var rstr = [">>>>>>", "<<<<<<", "******", "======", "++++++", "^^^^^^", "@@@@@@", "%%%%%%"];
            var randomrstr = rstr[Math.floor(Math.random() * rstr.length)];

            if (pattern != 'null') {
                randomrstr = pattern;
            }

            console.log(randomrstr, req);
            randomrstr = '';

        }
    },
    getPaginator: (req) => {
        let filter = {};
        filter.limit = 10;
        if (req.query.hasOwnProperty('limit')) {
            if (req.query.limit === '-1') {
                req.query.limit = config.threshold.docsLimit;
            }
            filter.limit = parseInt(req.query.limit);
        }
        filter.page = req.query.hasOwnProperty('page') ? Number(req.query.page) : 1;

        if (req.query.hasOwnProperty('sort')) {
            let arr = req.query.sort.split('-');
            filter.sort = {};
            if (arr.length === 2) {
                filter.sort[arr[1]] = -1;
            } else {
                filter.sort[arr[0]] = 1;
            }
        } else if (req.query.hasOwnProperty('sortBy')) {
            filter.sort = eval('(' + req.query.sortBy + ')');
        } else {
            filter.sort = {
                updatedAt: -1
            };
        }

        filter.select = '-__v';


        return filter;
    },

    getDtPaginator: (req) => {
        let filter = {};
        filter.page = (parseInt(req.body.start) / parseInt(req.body.length)) + 1;
        filter.limit = req.body.length;
        let sortField = req.body.columns[req.body.order[0].column].data;
        let sortDir = req.body.order[0].dir;
        let sortSign = (sortDir == "asc") ? " " : "-";

        // console.log(sortDir);
        // console.log(sortField);
        // console.log(sortSign);
        filter.sort = sortSign + sortField;
        return filter;
    },


    getAccessTokenFromHeader(req) {
        return (req.headers['authorization'] && req.headers['authorization'] !== null ? req.headers['authorization'].split(' ')[1] : null);
    },

    getAccessTokenFromUrl(req) {
        return (req.query.hasOwnProperty('Authorization') && Helper.getObject(req.query.Authorization) !== null ? req.query.Authorization : null);
    },

    getAccessTokenObj(req) {
        return (req.headers.hasOwnProperty('authorization') && (req.headers.authorization) !== null ? req.headers.authorization : null);
    },

    /**
     * Responds client with JSON response
     * @param res
     * @param statusCode
     * @returns {function(*=)}
     */
    respondAsJSON: (res, statusCode) => {
        statusCode = statusCode || 200;
        return (items) => {
            res.status(statusCode).json(items);
        }
    },

    /**
     * Handles error
     * @param res
     * @param statusCode
     * @returns {function(*=)}
     */
    handleError: (res, statusCode) => {
        statusCode = statusCode || 500;
        return (err) => 
        {
            Sentry.captureException(err);
            res.status(statusCode).send({ status: false, data: err });  
        }  
    },

    /**
     * Generate Transaction Id
     * @param prefix
     * @returns String

     */
    generateModelId: (prefix = 'ORD') => {
        let rand = require('unique-random')(1000000000, 9999999999);
        return prefix + rand();
        //return prefix + (Math.floor(new Date().getTime() + Math.random())).toString();// + (Math.floor(Math.random()*90) + 10).toString();
    },

    /**
     * Generate Transaction Id
     * @param prefix
     * @returns String

     */
    generateAlphanumericId: (prefix = 'ORD') => {
        let rand = require('unique-random')(1000 /*000000*/ , 9999 /*999999*/ );
        return (prefix + rand() + alphanumeric(4).toString()).toUpperCase();
        //return prefix + (Math.floor(new Date().getTime() + Math.random())).toString();// + (Math.floor(Math.random()*90) + 10).toString();
    },

    getEncKey: (resObj) => {
        let encKey = module.exports.getRandomString(20);
        let appendEncKey = module.exports.getRandomString(5);
        let finalString = appendEncKey + module.exports.reverseString(encKey) + module.exports.dataRkEnc(encKey, JSON.stringify(resObj));
        return finalString;
    },

    dataRkEnc: (key, data) => {
        let encrypted = aes256.encrypt(key, data);
        return encrypted
    },

    /***
     * @author prashant suthar
     * @date 18-10-2019
     * @param pwd
     * @returns {*|String|void|PromiseLike<ArrayBuffer>}
     * encrypt plain password
     */
    passwordEncrypt: (pwd) => {
        let key = constants.secret;
        let encrypted = aes256.encrypt(key, pwd);
        return encrypted;
    },
    /***
     * @author prashant suthar
     * @date 18-10-2019
     * @param pwd
     * @returns {*|String|void|PromiseLike<ArrayBuffer>}
     * decrypt plain password
     */
    passwordDecrypt: (pwd) => {
        let key = constants.secret;
        let decrypt = aes256.decrypt(key, pwd);
        return decrypt
    },

    randomNumber: (low, high) => {
        return Math.floor(Math.random() * (high - low) + low)
    },


    /**
     * Array Contains Function
     * @param array
     * @param value
     * @returns Boolean

     */
    contains: (array, value) => {
        if (array) {
            return array.indexOf(value) > -1;
        } else {
            return false;
        }
    },

    /**
     * Push Unique Value in Array
     * @param array
     * @param value
     * @returns Boolean

     */
    pushUnique: (array, value) => {
        if (array.indexOf(value) === -1) {
            array.push(value);
        }
    },

    isJSON: (str) => {
        try {
            JSON.parse(str);
        } catch (e) {
            return false;
        }
        return true;
    },

    /**
     * Responds create random string
     * @param res
     * @param no pram
     * @returns {function(*=)}
     */

    getRandomString: (length) => {
        var result = '';
        var characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        var charactersLength = characters.length;
        for (var i = 0; i < length; i++) {
            result += characters.charAt(Math.floor(Math.random() * charactersLength));
        }
        return result;
    },

    reverseString: (str) => {
        var splitString = str.split(""); // var splitString = "hello".split("");
        var reverseArray = splitString.reverse();
        var joinArray = reverseArray.join("");
        return joinArray;
    },

   
   
    /**
     * get object
     * @param obj
     * @returns Object

     */
    getObject: (obj) => {
        if (obj && obj !== undefined && obj !== null) {

            if (Array.isArray(obj) && obj.length === 0)
                return null;
            else
                return obj;

        } else {
            return null;
        }
    }
};
