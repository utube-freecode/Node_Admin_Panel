'use strict';
let Helper = require('../helpers/common.helper');
let constants = require(`../../config/${process.env.CONST_FILE}.js`);
let request = require('request-promise');
let jwt = require('jsonwebtoken');



function getAccessTokenFromHeader(req) {
    return (req.headers['authorization'] && req.headers['authorization'] !== null ? req.headers['authorization'].split(' ')[1] : null);
}

function getAccessTokenFromUrl(req) {
    return (req.query.hasOwnProperty('Authorization') && Helper.getObject(req.query.Authorization) !== null ? req.query.Authorization : null);
}

function getAccessTokenObj(req) {
    return (req.headers.hasOwnProperty('authorization') && (req.headers.authorization) !== null ? req.headers.authorization : null);
}

module.exports = {

    /**
     * Get Token from Request Header
     * @param req
     * @returns String
     
     */
    getAccessToken: (req) => {
        return getAccessTokenFromHeader(req) || getAccessTokenFromUrl(req) || getAccessTokenObj(req);
    },


    /**
     * OAuth 2 Token Validation
     * @param req
     * @param res
     * @param next
     * @returns Boolean

     */


    /**
 * OAuth 2 Token Validation
 * @param req
 * @param res
 * @param next
 * @returns Boolean

 */
    client: (req, res, next) => {
        let tokenfromheader = getAccessTokenFromHeader(req) || getAccessTokenFromUrl(req);
        let tokenErr = {};
        let response = {};

        if (tokenfromheader == constants.adminhash) {
            next();
        } else {
            res.status(401).send({
                status: false,
                message: 'UnAthorize access.',
                data: '',
            });
        }

        // UserDeviceInformation.findOne({
        //   token: tokenfromheader,
        // }).then(
        //   response => {
        //      if(response){
        //        next();
        //      }else{
        //       res.status(401).send({
        //         status: false,
        //         message: 'UnAthorize access.',
        //         data: '',
        //     });
        //      }
        //   }
        // ).catch(Helper.handleError(res));
    },
};