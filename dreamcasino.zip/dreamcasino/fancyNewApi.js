'use strict';

process.env.NODE_ENV = process.env.NODE_ENV || 'development';
process.env.CONST_FILE = process.env.CONST_FILE || 'constants';
let express = require('express');
let app = express();
let bodyParser = require('body-parser');
let mongoose = require('mongoose');
let Promise = require('bluebird');
let port = process.env.PORT || 5056;
// let http = require('http');
// let server = http.Server(app);
var server = app.listen(port);
const WebSocketClient = require('websocket').client;
let config = require(`./config/production.js`);
//let config = require(`./config/${process.env.NODE_ENV}.js`);
let compression = require('compression');
const error = require('./app/helpers/error');
var schedule = require('node-schedule');
let validator = require('express-validator');
let requestify = require('requestify');
let _ = require('underscore');
let shell = require('shelljs');

var cors = require('cors');

// var Redisclient = redis.createClient(); //creates a new client
var redisc = require('redis');
var Redisclient = redisc.createClient(
    27019,
    'redis.getlivefeed.xyz',
    {
        auth_pass: 'codebrik#321',
        no_ready_check: true,
    }
).on('error', function (err) {
    console.log('connect');
    //console.log('Redis error fancy' + config.redis.dbHost + ":" + config.redis.port + " " + err);
})
    .on('connect', function () {
        console.log('connectaaaaa');
        //console.log('Redis connected fancy ' +  config.redis.dbHost + ":" + config.redis.port);
    });
    console.log('saAAAAAAAAAAAAAAA');
// require('./app/helpers/logging')();
// require('./app/helpers/validation')();
console.log('asdasd');
// let dbUrl = "mongodb://codebrik:codebrik#321@194.233.69.240:27017/activeApi?authSource=admin";
let dbUrl = "mongodb://codebrik:codebrik#321@194.233.69.240:27017/activeApi?authSource=admin";

mongoose.Promise = Promise;
let mongoOptions = { poolSize: 100 };
console.log('Mongo Options: ', mongoOptions);
console.log('config.database.URI,', dbUrl);
console.log('config.mongoOptions.URI,', mongoOptions);
mongoose.connect(
    dbUrl, { useNewUrlParser: true }
);
let socketIO = require('socket.io');
var redis = require('socket.io-redis');

let roomAry = [];
// // var allowedOrigins = "http://173.212.238.127:*, http: //socket.myfancy.xyz:*, http: //office.myfancy.xyz:*,    http: //admin.myfancy.xyz:*,    http: //server.myfancy.xyz:*,    http: //myfancy.xyz:*,http: //www.myfancy.xyz:*,    http: //socket.pam11.com:*,     http: //office.pam11.com:*,    http: //admin.pam11.com:*,    http: //server.pam11.com:*,    http: //pam11.com:*,http: //www.pam11.com:*,    http: //socket.samudra9exch.com:*,    http: //office.samudra9exch.com:*,   http: //admin.samudra9exch.com:*,    http: //server.samudra9exch.com:*,    http: //samudra9exch.com:*,http: //www.samudra9exch.com:*,    http: //socket.pam555.xyz:*,    http: //office.pam555.xyz:*,    http: //admin.pam555.xyz:*,    http: //server.pam555.xyz:*,    http: //pam555.xyz:*,http: //www.pam555.xyz:*,    http: //socket.a1live.xyz:*,    http: //office.a1live.xyz:*,    http: //admin.a1live.xyz:*,    http: //server.a1live.xyz:*,    http: //a1live.xyz:*,http: //www.a1live.xyz:*";
var allowedOrigins = '*:*';
let io = socketIO(server, {
    origins: allowedOrigins
});
// let io = ();
app.set('socketio', io);
io.set('transports', ['websocket',
    'flashsocket',
    'htmlfile',
    'xhr-polling',
    'jsonp-polling',
    'polling'
]);


//io.adapter(redis({ host: 'localhost', port: 6379 }));
// io.adapter(redis({
//     host: config.redis.dbHost,
//     port: config.redis.port,
//     auth_pass: config.redis.dbOptions.auth_pass
// }));
var allowcatedIP = [
    '122.170.70.58', // local
    '194.233.69.240', // main
    '173.212.238.127', // pam11
    '62.171.172.154', // redis 
    '95.111.229.236' // samudra new
    // '122.170.48.133'
];




io.on('error', function (err) {
    console.log('Redis error fancy' + config.redis.dbHost + ":" + config.redis.port + " " + err);
}).on('connection', (socket) => {
    socket.on('join-room', (roomId) => {
        socket.join(roomId);
    });
    socket.on('leave-room', (roomId) => {
        socket.leave(roomId);
    });
    socket.on('disconnect', (reason) => {
        // console.log(`Disconnected: ${error || reason}`);
    });

});




app.use(cors({ credentials: true, origin: '*' }));

app.use(cors());
app.use(bodyParser.urlencoded(config.bodyParser.urlencoded));
app.use(bodyParser.json(config.bodyParser.json));
app.use(compression());
app.use(validator());


app.get('/', function(req, res) {
    res.send('')
});
app.use(express.static(__dirname + '/public'));

// require('./routes.js')(app);
app.use(error);

// let oddsApi = require('./app/models/oddsApi.model');
// const { consolelog } = require('./app/helpers/common.helper.js');


let setFancyCron = schedule.scheduleJob('*/1 * * * * *', function(fireDate) {

     // startInervalofBMSamudra();

    Redisclient.get("fancyAllListNew", function(err, response) {
        if (err) throw err;
        var i = 0;
        var timeer = setInterval(function() {
        startInervalofFancySamudra(JSON.parse(response));

        // updateRedisBookmaker(JSON.parse(response));
            if (i == 1) {
                clearInterval(timeer);
            }
            i = i + 1;
        }, 500);
    });
});

let setFancyCron1 = schedule.scheduleJob('*/7 * * * * *', function(fireDate) {
    
    Redisclient.get("fancyLiveRate", function(err, response) {
        console.log('bla bla bla');
         response = JSON.parse(response);
         console.log('response+++++++',response);
        let resultData = _.reject(response, function(d){ return d.result == null; });
        updateRedisFancyResult(resultData);
        Redisclient.set("fancyLiveResultItems", JSON.stringify(resultData));

    })

});

let setFancyCron34 = schedule.scheduleJob('*/1 * * * * *', function(fireDate) {
    Redisclient.get("fancyLiveRate", function(err, response) {
        response = JSON.parse(response);
        let resultData = _.reject(response, function(d){ return d.oddsData.status != 'CLOSED'; });
        Redisclient.set("fancyInActiveData", JSON.stringify(resultData));
    })

});


function startInervalofFancySamudraOld() {
    var i = 0;
        var timeer = setInterval(function() {
            let finalResult = [];

            let sportAry = [1,2,4];
            let count = 0;
            // for(let k=0;k<sportAry.length;k++){

            // }

            var requestArray = {
                method: 'POST',
                // body: bodyData,
                headers: {
                    'Content-Type': 'application/json',
                    'Origin' : 'http://getlivefeed.xyz'
                },
                dataType: 'json'
            };
            let data = { sportId:4}
            let url = "https://apiuniverse.live/client/exchange/fancy/fancyOddsgamefeeds";
            requestify.post(url,data,requestArray)
            .then(function(response) {
                    if(response.code == 200){
                        let result = JSON.parse(response.body);
                        // finalResult.concat(result.data)
                        // finalResult = [...finalResult, ...result.data];

                            // Redisclient.set("fancyLiveRate", JSON.stringify(result.data));
                        count = count + 1
                    }
            })



            if (i == 1) {
                clearInterval(timeer);
            }
             i = i + 1;
     }, 800);
}


function startInervalofFancySamudra(matchIds) {
            var requestArray = {
                method: 'POST',
                // body: bodyData,
                headers: {
                    'Content-Type': 'application/json',
                    'Origin' : 'http://getlivefeed.xyz'
                },
                dataType: 'json'
            };
            let data = { sportId:4}
            let url = "https://apiuniverse.live/client/exchange/fancy/fancyOddsgamefeeds";
            requestify.post(url,data,requestArray)
            .then(function(response) {
                    if(response.code == 200){
                        let result = JSON.parse(response.body);
                        Redisclient.set("fancyLiveRate", JSON.stringify(result.data));
                        let liveRate = _.reject(result.data, function(d){ return d.oddsData.status == 'CLOSED';});
                        liveRate = _.reject(liveRate, function(d){ return d.marketName.match("Over Boundaries");});
                        liveRate = _.reject(liveRate, function(d){ return d.marketName.match("Over Dotball");});
                        Redisclient.set("fancyLiveImport", JSON.stringify(liveRate));
                        updateRedisFancy(liveRate);
                        Redisclient.set("fancyLiveRate1", JSON.stringify(result.data));
                    }
            })
}

function updateRedisFancy(data) {
            if(data){
                _.map( data, function( fancy,index ) {
                    let obj =  {
                            "srno": fancy.exMarketId,
                            "rates": {
                            "0": {
                                "rate_1": fancy.oddsData.runners[0].price.lay[0].price,
                                "rate_2": fancy.oddsData.runners[0].price.back[0].price,
                                "value_1": fancy.oddsData.runners[0].price.lay[0].size,
                                "value_2": fancy.oddsData.runners[0].price.back[0].size
                                }
                            },
                            "team": "A",
                            "status": (fancy.oddsData.status == 'ONLINE') ? '0' : (fancy.oddsData.status == 'BALLRUN') ? '1' : '2',
                            "result": fancy.result,
                            "news": fancy.news
                        };
                    console.log(fancy)
                    // io.sockets.to(fancy.exMarketId).emit('fancy-auto-rate', obj);
                     Redisclient.set(fancy.exMarketId, JSON.stringify(obj), 'EX', 60000);
                });

         }

}

function updateRedisFancyResult(data) {
    _.map( data, function( fancy ,index ) {
        Redisclient.set(fancy.exMarketId, JSON.stringify(fancy));
    });
                    Redisclient.set('result_fancy_new', JSON.stringify(data));
                    Redisclient.set('result_fancy_bt', JSON.stringify(data));
                    Redisclient.set('result_fancy_sm', JSON.stringify(data))
}

function startInervalofBMSamudra() {
    var i = 0;
        var timeer = setInterval(function() {

            var requestArray = {
                method: 'POST',
                // body: bodyData,
                headers: {
                    'Content-Type': 'application/json',
                    'Origin' : 'http://getlivefeed.xyz'
                },
                dataType: 'json'
            };
            let data = { sportId:4}
            let url = "https://apiuniverse.live/client/exchange/bookmakers/bookmakersOddsgamefeeds";
            requestify.post(url,data,requestArray)
            .then(function(response) {
                    if(response.code == 200){
                        let result = JSON.parse(response.body);
                            Redisclient.set("bmLiveRate", JSON.stringify(result.data));
                    }
            })
            if (i == 1) {
                clearInterval(timeer);
            }
             i = i + 1;
     }, 500);
}

function updateRedisBookmaker(matchIds) {
        let matchAry = [];
        _.filter(matchIds, function(o) {
                matchAry.push(o.fancymarketId);
        });
        var i = 0;
        var timeer = setInterval(function() {
            Redisclient.get("bmLiveRate", function(err, response) {
                response = JSON.parse(response);
                if(response && response.length > 0){
                    _.map( response, function( fancy ) {
                        let rateObj = {};
                        let selectionId = '';
                        let multipleAry = 0;
                        let allRunnerMultiAry = 0;
                        let allRunnerIds = '';
                        let runnerRateAry = {};
                       _.map( fancy.oddsData.runners, function( runnerRate ) {
                            if(allRunnerMultiAry > 0){
                                 allRunnerIds = allRunnerIds + "," + runnerRate.selectionId;
                            }else{
                                allRunnerIds = runnerRate.selectionId
                            }
                            allRunnerMultiAry = allRunnerMultiAry + 1;
                            if(runnerRate.status == 'ONLINE'){
                                let backrate = runnerRate.price.back;
                                let layrate = runnerRate.price.lay;
                                let runnerWiseRate = {};
                                // if(backrate[0].price != 0){
                                // backrate[0].price = (backrate[0].price < 0) ? 0 :backrate[0].price;
                                runnerWiseRate.rate_1 = (backrate[0].price == 0) ? backrate[0].price : Math.round((backrate[0].price - 1) * 100);
                                    runnerWiseRate.value_1 = backrate[0].size;

                                    rateObj.rate_1 = (backrate[0].price == 0) ? backrate[0].price : Math.round((backrate[0].price - 1) * 100);
                                    rateObj.value_1 = backrate[0].size;
                                // }

                                // if(layrate[0].price != 0){
                                //     layrate[0].price = (layrate[0].price < 0) ? 0 :layrate[0].price;
                                    runnerWiseRate.rate_2 = (layrate[0].price == 0) ? layrate[0].price : Math.round((layrate[0].price - 1) * 100);
                                    runnerWiseRate.value_2 = layrate[0].size;

                                    rateObj.rate_2 = (layrate[0].price == 0) ? layrate[0].price : Math.round((layrate[0].price - 1) * 100);
                                    rateObj.value_2 = layrate[0].size;
                                    let runRate = {
                                        [runnerRate.selectionId] : runnerWiseRate
                                    }
                                    runnerRateAry = {...runnerRateAry, ...runRate};
                                // }
                                if(multipleAry > 0){
                                    selectionId = selectionId + "," + runnerRate.selectionId;
                                }else{
                                    selectionId = runnerRate.selectionId;
                                }
                                multipleAry = multipleAry + 1;
                            }
                        })
                        let obj =  {
                                "srno": fancy.exMarketId,
                                "rates": {
                                "0": rateObj
                                },
                                "team": (multipleAry > 1) ? "D" : "A",
                                "runnerRateAry" : runnerRateAry,
                                "selectid" : selectionId,
                                "allRunnerIds" : allRunnerIds,
                               "status": (fancy.oddsData.status == 'ONLINE') ? '0' : (fancy.oddsData.status == 'BALLRUN') ? '1' : '2',
                            "result": fancy.result,
                            "news": fancy.news
                            };

                         io.sockets.to(fancy.exMarketId).emit('fancy-auto-rate', obj);
                        Redisclient.set(fancy.exMarketId, JSON.stringify(obj), 'EX', 60000);
                        Redisclient.set('book_'+fancy.exMarketId, JSON.stringify(fancy));

                   });
                }
            });
            if (i == 2) {
                clearInterval(timeer);
            }
             i = i + 1;
        },400);
}





console.log('Fancy API running now. ' + port);